class ResponseHandler {
    /**
     * Sends a standardized response.
     *
     * @param {Object|Array} data - The response data, can be an object or an array.
     * @param {string} message - The success or error message.
     * @param {number} statusCode - The HTTP status code.
     * @returns {Object} - The standardized response object.
     */
    static sendResponse(data, message, statusCode) {
      const response = {
        status: statusCode,
        httpStatus: this.getHttpStatus(statusCode),
        successMsg: null,
        errorMsg: null,
        data: null,
        dataList: null,
      };
  
      if (statusCode === 200 || statusCode === 201) {
        response.successMsg = message;
      } else {
        response.errorMsg = message;
      }
  
      if (Array.isArray(data)) {
        response.dataList = data;
      } else {
        response.data = data;
      }
  
      return response;
    }
  
    /**
     * Maps an HTTP status code to a human-readable status name.
     *
     * @param {number} statusCode - The HTTP status code.
     * @returns {string} - The corresponding HTTP status name.
     */
    static getHttpStatus(statusCode) {
      const httpStatusMap = {
        200: 'OK',
        201: 'Created',
        400: 'Bad Request',
        401: 'Unauthorized',
        403: 'Forbidden',
        404: 'Not Found',
        422: 'Unprocessable Entity',
        500: 'Internal Server Error',
      };
  
      return httpStatusMap[statusCode] || 'Unknown Status';
    }
  
    /**
     * Sends a response for HTTP exceptions.
     *
     * @param {string} resp - The raw response string (usually from an external service).
     * @returns {Object} - The standardized response object.
     */
    static sendHttpExpResponse(resp) {
      try {
        const parsedResponse = JSON.parse(resp);
  
        const response = {
          status: parsedResponse.status || 500,
          httpStatus: this.getHttpStatus(parsedResponse.status || 500),
          errorMsg: parsedResponse.error || 'Internal Server Error',
          data: parsedResponse.data || null,
        };
  
        return response;
      } catch (err) {
        return {
          status: 500,
          httpStatus: this.getHttpStatus(500),
          errorMsg: 'Invalid response format or internal error.',
          data: null,
        };
      }
    }
  
    /**
     * Sends an error response.
     *
     * @param {string} message - The error message.
     * @param {number} statusCode - The HTTP status code.
     * @returns {Object} - The standardized response object.
     */
    static sendErrorResponse(message, statusCode) {
      return {
        status: statusCode,
        httpStatus: this.getHttpStatus(statusCode),
        errorMsg: message,
        data: null,
      };
    }
  }
  
  module.exports = ResponseHandler;
  