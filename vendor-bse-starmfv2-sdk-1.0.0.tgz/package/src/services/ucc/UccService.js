// const { endpoints } = require("../../constants/endpoints");
// const UccListApiRequest = require("../../models/ucc/UccListApiRequest");
// const { errorParser } = require("../../utils/errorParser");
// const { setBearerToken } = require("../../utils/RequestFunction");
// const { api } = require("../api/Api");

// // Create UCC

// exports.createUcc = async (bearerToken = "", requestDto = {}) => {
//   try {
//     let bseUrl = endpoints.ucc.add_ucc;

//     // console.log("bearerToken", bearerToken);

//     // setting bearer token in header
//     let config = setBearerToken(bearerToken);
//     // console.log("config", config);

//     //create a varaible for payload
//     let data = {
//       ...requestDto,
//     };
//     // console.log("request create Ucc data", data);

//     const response = await api._post(bseUrl, data, config);

//     return response.data;
//   } catch (error) {
//     // console.log("errorObj in ucc", error);
//     let errorObj = errorParser(error);
//     return errorObj.data;
//   }
// };

// //Get All UCC

// exports.getAllUcc = async (bearerToken = "", requestDto = {}) => {
//   try {
//     let bseUrl = endpoints.ucc.list_ucc;

//     let config = setBearerToken(bearerToken);

//     let payload = new UccListApiRequest(requestDto?.data);

//     console.log("payload instance get all ucc", payload);

//     const response = await api._post(bseUrl, payload, config);

//     return response.data;
//   } catch (error) {
//     let errorObj = errorParser(error);
//     return errorObj.data;
//   }
// };

// //Get Particular UCC

// exports.getParticularUcc = async (bearerToken = "", requestDto = {}) => {
//   try {
//     let bseUrl = endpoints.ucc.get_ucc;

//     // console.log("bearerToken", bearerToken);

//     // setting bearer token in header
//     let config = setBearerToken(bearerToken);
//     // console.log("config", config);

//     //create a varaible for payload
//     let data = {
//       ...requestDto,
//     };
//     // console.log("request create Ucc data", data);

//     const response = await api._post(bseUrl, data, config);

//     return response.data;
//   } catch (error) {
//     // console.log("errorObj in ucc", error);
//     let errorObj = errorParser(error);
//     return errorObj.data;
//   }
// };

// //Update UCC Update Communication Address

// exports.updateUccAddress = async (
//   bearerToken = "",
//   uccUpdateCommAddressApiRequestDto = {}
// ) => {
//   try {
//     let bseUrl = endpoints.ucc.update_ucc;

//     // console.log("bearerToken", bearerToken);

//     // setting bearer token in header
//     let config = setBearerToken(bearerToken);
//     // console.log("config", config);

//     //create a varaible for payload
//     let data = {
//       ...uccUpdateCommAddressApiRequestDto,
//     };
//     // console.log("request create Ucc data", data);

//     const response = await api._post(bseUrl, data, config);

//     return response.data;
//   } catch (error) {
//     // console.log("errorObj in ucc", error.response?.data);
//     let errorObj = errorParser(error);
//     return errorObj.data;
//   }
// };

// //Update UCC Profile

// exports.updateUccPofile = async (
//   bearerToken = "",
//   uccUpdateCommAddressApiRequestDto = {}
// ) => {
//   try {
//     let bseUrl = endpoints.ucc.update_ucc;

//     // console.log("bearerToken", bearerToken);

//     // setting bearer token in header
//     let config = setBearerToken(bearerToken);
//     // console.log("config", config);

//     //create a varaible for payload
//     let data = {
//       ...uccUpdateCommAddressApiRequestDto,
//     };
//     // console.log("request create Ucc data", data);

//     const response = await api._post(bseUrl, data, config);

//     return response.data;
//   } catch (error) {
//     // console.log("errorObj in ucc", error.response?.data);
//     let errorObj = errorParser(error);
//     return errorObj.data;
//   }
// };

// //Update Ucc Update Bank Data

// exports.updateUccUpdateBankData = async (
//   bearerToken = "",
//   uccUpdateBankApiRequest = {}
// ) => {
//   try {
//     let bseUrl = endpoints.ucc.update_ucc;

//     // console.log("bearerToken", bearerToken);

//     // setting bearer token in header
//     let config = setBearerToken(bearerToken);

//     //create a varaible for payload
//     let data = {
//       ...uccUpdateBankApiRequest,
//     };
//     // console.log("request create Ucc data", data);

//     const response = await api._post(bseUrl, data, config);

//     return response.data;
//   } catch (error) {
//     // console.log("errorObj in ucc", error);
//     let errorObj = errorParser(error);
//     return errorObj.data;
//   }
// };

const { endpoints } = require("../../constants/endpoints");
const UccListApiRequest = require("../../models/ucc/UccListApiRequest");
const { errorParser } = require("../../utils/errorParser");
const { setBearerToken } = require("../../utils/RequestFunction");
const Api = require("../api/Api");
// const { api } = require("../api/Api");

class UccService {
  constructor(data) {
    this.endpoints = endpoints.ucc;
    this.api = new Api(data);
  }

  async getAllUcc(bearerToken = "", requestDto = {}) {
    try {
      let config = setBearerToken(bearerToken);
      let payload = new UccListApiRequest(requestDto?.data);
      const response = await this.api._post(
        this.endpoints.list_ucc,
        payload,
        config
      );
      return response.data;
    } catch (error) {
      console.log("get All UCC Error" , errorParser(error).data)
      return errorParser(error).data;
    }
  }

  async createUcc(bearerToken = "", createRequest = {}) {
    try {
      let config = setBearerToken(bearerToken);
      let data = { ...createRequest };
      const response = await this.api._post(this.endpoints.add_ucc, data, config);
      return response.data;
    } catch (error) {
      console.log("Create UCC Error" , errorParser(error).data)
      return errorParser(error).data;
    }
  }

  async createPhysicalUcc(
    bearerToken = "",
    createUccRequestDto = {}
  ) {
    return this.createUcc(bearerToken, createUccRequestDto);
  }

  async createDematUcc(
    bearerToken = "",
    createUccRequestDto = {}
  ) {
    return this.createUcc(bearerToken, createUccRequestDto);
  }

  async createBothUcc(
    bearerToken = "",
    createUccRequestDto = {}
  ) {
    return this.createUcc(bearerToken, createUccRequestDto);
  }


  // async createIndividualUcc(bearerToken = "", requestDto = {}) {
  //   try {
  //     let config = setBearerToken(bearerToken);
  //     let data = { ...requestDto };
  //     const response = await this.api._post(this.endpoints.add_ucc, data, config);
  //     return response.data;
  //   } catch (error) {
  //     return errorParser(error).data;
  //   }
  // }

  async getParticularUcc(bearerToken = "", requestDto = {}) {
    console.log("requestDto get UCC", requestDto);
    try {
      let config = setBearerToken(bearerToken);
      let data = { ...requestDto };
      const response = await this.api._post(this.endpoints.get_ucc, data, config);
      return response.data;
    } catch (error) {
      console.log("get Particular UCC Error" , errorParser(error).data)
      return errorParser(error).data;
    }
  }

  async updateUcc(bearerToken = "", updateRequest = {}) {
    try {
      let config = setBearerToken(bearerToken);
      let data = { ...updateRequest };
      const response = await this.api._post(this.endpoints.update_ucc, data, config);
      return response.data;
    } catch (error) {
      return errorParser(error).data;
    }
  }

  async updateUccAddress(
    bearerToken = "",
    uccUpdateCommAddressApiRequestDto = {}
  ) {
    return this.updateUcc(bearerToken, uccUpdateCommAddressApiRequestDto);
  }

  async updateUccProfile(
    bearerToken = "",
    uccUpdateCommAddressApiRequestDto = {}
  ) {
    return this.updateUcc(bearerToken, uccUpdateCommAddressApiRequestDto);
  }

  async updateUccUpdateBankData(
    bearerToken = "",
    uccUpdateBankApiRequest = {}
  ) {
    return this.updateUcc(bearerToken, uccUpdateBankApiRequest);
  }

  async deactivateUcc(
    bearerToken = "",
    deactivateUccRequestDto = {}
  ) {
    return this.updateUcc(bearerToken, deactivateUccRequestDto);
  }
}

module.exports = UccService;
