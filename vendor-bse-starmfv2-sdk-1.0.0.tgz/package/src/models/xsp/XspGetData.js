class XspGetData {
    constructor(data = {}) {
        this.reg_no = data?.reg_no || "";
      }
}

module.exports = XspGetData ;