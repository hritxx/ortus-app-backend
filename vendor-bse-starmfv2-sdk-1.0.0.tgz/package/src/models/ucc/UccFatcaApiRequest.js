const UccUpdateFatcaData = require("./UccUpdateFatcaData");

class UccFatcaApiRequest {
    constructor(data) {
        this.data = data ? new UccUpdateFatcaData(data) : null;
    }
}

module.exports = UccFatcaApiRequest;
