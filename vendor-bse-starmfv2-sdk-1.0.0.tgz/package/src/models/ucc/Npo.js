class Npo {
    constructor(data) {
        this.npo_form = data?.npo_form || false;
        this.npo_dcl = data?.npo_dcl || false;
        this.npo_rg_no = data?.npo_rg_no || '';
    }
}

module.exports = Npo;  