const MasterSearch = {
    constructor(data = {}) {
        this.value = data.value || "";
    }
};

module.exports = MasterSearch;
