class Investor {
    constructor(data = {}) {
        this.ucc = data?.ucc || "";
      }
}

module.exports = Investor ;