const GuardianDto = require("./GuardianDto");
const IdentifierDto = require("./IdentifierDto");

class NominationDto {
  constructor(data) {
    this.person = data?.person || null;
    this.nomination_percent = data?.nomination_percent || "";
    this.nomination_relation = data?.nomination_relation || "";
    this.is_pan_exempt = data?.is_pan_exempt || false;
    this.pan_exempt_category = data?.pan_exempt_category || "";
    this.is_minor = data?.is_minor || false;
    this.identifier = data?.identifier
      ? data.identifier.map((identifier) => new IdentifierDto(identifier))
      : [];
    this.guardian = new GuardianDto(data?.guardian) || null;
    this.holder_name = data?.holder_name || "";
    this.first_name = data?.first_name || "";
    this.middle_name = data?.middle_name || "";
    this.last_name = data?.last_name || "";
    this.dob = data?.dob || "";
  }
}

module.exports = NominationDto;
