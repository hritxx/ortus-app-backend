const OrderListData = require("./OrderListData");

class OrderNewPurchaseRequest {
  constructor(data = {}) {
    this.data = data ? new OrderListData(data) : null;
  }
}

module.exports = OrderNewPurchaseRequest;
