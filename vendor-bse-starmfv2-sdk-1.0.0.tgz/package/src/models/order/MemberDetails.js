class MemberDetails {
  constructor(data = {}) {
    this.euin = data?.euin || "";
    this.euin_flag = data?.euin_flag || "";
    this.sub_br_code = data?.sub_br_code || "";
    this.sub_br_arn = data?.sub_br_arn || "";
    this.partner_id = data?.partner_id || "";
  }
}

module.exports = MemberDetails;
