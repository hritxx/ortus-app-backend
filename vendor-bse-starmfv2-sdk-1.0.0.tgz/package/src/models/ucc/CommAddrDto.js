// CommAddrDto.js

class CommAddrDto {
    constructor(addressLine1, addressLine2, addressLine3, commMode, postalcode, addressId) {
        this.addressLine1 = addressLine1;
        this.addressLine2 = addressLine2;
        this.addressLine3 = addressLine3;
        this.commMode = commMode;
        this.postalcode = postalcode;
        this.addressId = addressId;
    }

    getAddressLine1() {
        return this.addressLine1;
    }

    setAddressLine1(addressLine1) {
        this.addressLine1 = addressLine1;
    }

    getAddressLine2() {
        return this.addressLine2;
    }

    setAddressLine2(addressLine2) {
        this.addressLine2 = addressLine2;
    }

    getAddressLine3() {
        return this.addressLine3;
    }

    setAddressLine3(addressLine3) {
        this.addressLine3 = addressLine3;
    }

    getCommMode() {
        return this.commMode;
    }

    setCommMode(commMode) {
        this.commMode = commMode;
    }

    getPostalcode() {
        return this.postalcode;
    }

    setPostalcode(postalcode) {
        this.postalcode = postalcode;
    }

    getAddressId() {
        return this.addressId;
    }

    setAddressId(addressId) {
        this.addressId = addressId;
    }
}

module.exports = CommAddrDto;
