class BankAccount {
  constructor(data = {}) {
    this.ifsc = data.ifsc || "";
    this.no = data.no || "";
    this.type = data.type || "";
    this.name = data.name || "";
  }
}

module.exports = BankAccount;
