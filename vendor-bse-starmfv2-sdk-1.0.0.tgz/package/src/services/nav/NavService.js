const { endpoints } = require("../../constants/endpoints");
const { errorParser } = require("../../utils/errorParser");
const { setBearerToken } = require("../../utils/RequestFunction");
const Api = require("../api/Api");

class NavService {
  constructor(data) {
    this.api = new Api(data);
    this.endpoints = endpoints;
  }

  async getNavMasterList(bearerToken = "", requestDto = {}) {
    try {
      let config = setBearerToken(bearerToken);
      const response = await this.api._post(
        this.endpoints.nav.nav_master_list,
        requestDto,
        config
      );
      return response.data;
    } catch (error) {
      return errorParser(error).data;
    }
  }
}

module.exports = NavService;
