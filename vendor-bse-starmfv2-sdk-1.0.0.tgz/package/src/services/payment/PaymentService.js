// const { endpoints } = require("../../constants/endpoints");
// const { errorParser } = require("../../utils/errorParser");
// const { setBearerToken } = require("../../utils/RequestFunction");
// const { api } = require("../api/Api");

// //Payment Report

// exports.paymentReport = async (
//   memberCode = "",
//   bearerToken = "",
//   req = {}
// ) => {
//   try {
//     let bseUrl = endpoints.paymentAggregator.upload_mis;

//     // console.log("bearerToken", bearerToken);

//     // setting bearer token in header
//     let config = setBearerToken(bearerToken);
//     // console.log("config", config);

//     //create a varaible for payload
//     let data = {
//       ...req,
//     };

//     // console.log("request create Ucc data", data);

//     const response = await api._post(bseUrl, data, config);
//     // console.log("Cancel Purchase Order Completed");

//     return response.data;
//   } catch (error) {
//     // console.log("errorObj in ucc", error);
//     let errorObj = errorParser(error);
//     return errorObj.data;
//   }
// };

// //Get Payment MIS Details

// exports.getPaymentMisDetails = async (
//     memberCode = "",
//     bearerToken = "",
//     req = {}
//   ) => {
//     try {
//       let bseUrl = endpoints.paymentAggregator.get_mis_detail;
  
//       // console.log("bearerToken", bearerToken);
  
//       // setting bearer token in header
//       let config = setBearerToken(bearerToken);
//       // console.log("config", config);
  
//       //create a varaible for payload
//       let data = {
//         ...req,
//       };
  
//       // console.log("request create Ucc data", data);
  
//       const response = await api._post(bseUrl, data, config);
//       // console.log("Cancel Purchase Order Completed");
  
//       return response.data;
//     } catch (error) {
//       // console.log("errorObj in ucc", error);
//       let errorObj = errorParser(error);
//       return errorObj.data;
//     }
//   };


const { endpoints } = require("../../constants/endpoints");
const { errorParser } = require("../../utils/errorParser");
const { setBearerToken } = require("../../utils/RequestFunction");
const Api = require("../api/Api");

class PaymentService {
  constructor(data) {
    this.api = new Api(data);
    this.endpoints = endpoints;
  }
  async paymentReport(bearerToken = "", req = {}) {
    try {
      const endpoint = this.endpoints.paymentAggregator.upload_mis;
      const config = setBearerToken(bearerToken);
      const data = { ...req };
      const response = await this.api._post(endpoint, data, config);
      return response.data;
    } catch (error) {
      const errorObj = errorParser(error);
      return errorObj.data;
    }
  }

  async getPaymentMisDetails(bearerToken = "", req = {}) {
    try {
      const endpoint = this.endpoints.paymentAggregator.get_mis_detail;
      const config = setBearerToken(bearerToken);
      const data = { ...req };
      const response = await this.api._post(endpoint, data, config);
      return response.data;
    } catch (error) {
      const errorObj = errorParser(error);
      return errorObj.data;
    }
  }
}

module.exports = PaymentService;
