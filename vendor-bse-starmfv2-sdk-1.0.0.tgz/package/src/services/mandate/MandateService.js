const { endpoints } = require("../../constants/endpoints");
const { errorParser } = require("../../utils/errorParser");
const { setBearerToken } = require("../../utils/RequestFunction");
const Api = require("../api/Api");

class MandateService {
  constructor(data) {
    this.api = new Api(data);
    this.endpoints = endpoints;
  }

  async mandateRegister(bearerToken = "", createRequest = {}) {
    try {
      let config = setBearerToken(bearerToken);
      let data = { ...createRequest };
      const response = await this.api._post(
        this.endpoints.mandate.mandate_register,
        data,
        config
      );
      return response.data;
    } catch (error) {
      console.log("Create UCC Error", errorParser(error).data);
      return errorParser(error).data;
    }
  }

  async registerMandate(bearerToken = "", registerMandateRequestDto = {}) {
    return this.mandateRegister(bearerToken, registerMandateRequestDto);
  }

  async registerMandateUPI(bearerToken = "", registerMandateRequestDto = {}) {
    return this.mandateRegister(bearerToken, registerMandateRequestDto);
  }

  async registerMandateEnach(bearerToken = "", registerMandateRequestDto = {}) {
    return this.mandateRegister(bearerToken, registerMandateRequestDto);
  }

  async registerMandateNach(bearerToken = "", registerMandateRequestDto = {}) {
    return this.mandateRegister(bearerToken, registerMandateRequestDto);
  }

  async getMandate(bearerToken = "", requestDto = {}) {
    try {
      let config = setBearerToken(bearerToken);
      const response = await this.api._post(
        this.endpoints.mandate.mandate_get,
        requestDto,
        config
      );
      return response.data;
    } catch (error) {
      return errorParser(error).data;
    }
  }

  async getAllMandate(bearerToken = "", requestDto = {}) {
    try {
      let config = setBearerToken(bearerToken);
      const response = await this.api._post(
        this.endpoints.mandate.mandate_list,
        requestDto,
        config
      );
      return response.data;
    } catch (error) {
      return errorParser(error).data;
    }
  }

  async cancelMandate(bearerToken = "", requestDto = {}) {
    try {
      let config = setBearerToken(bearerToken);
      const response = await this.api._post(
        this.endpoints.mandate.mandate_cancel,
        requestDto,
        config
      );
      return response.data;
    } catch (error) {
      return errorParser(error).data;
    }
  }

  async linkMandate(bearerToken = "", requestDto = {}) {
    try {
      let config = setBearerToken(bearerToken);
      const response = await this.api._post(
        this.endpoints.mandate.link_mandate,
        requestDto,
        config
      );
      return response.data;
    } catch (error) {
      return errorParser(error).data;
    }
  }

  async mandateDelink(bearerToken = "", requestDto = {}) {
    try {
      let config = setBearerToken(bearerToken);
      const response = await this.api._post(
        this.endpoints.mandate.mandate_delink,
        requestDto,
        config
      );
      return response.data;
    } catch (error) {
      return errorParser(error).data;
    }
  }

  async updateMandate(bearerToken = "", requestDto = {}) {
    try {
      let config = setBearerToken(bearerToken);
      const response = await this.api._post(
        this.endpoints.mandate.mandate_update,
        requestDto,
        config
      );
      return response.data;
    } catch (error) {
      return errorParser(error).data;
    }
  }
}

module.exports = MandateService;
