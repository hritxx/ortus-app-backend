const LoginResponseData = require('./LoginResponseData');
const LoginResponseMessage = require('./LoginResponseMessage');

class LoginResponse {
  constructor(response) {
    this.status = response.status;
    this.data = new LoginResponseData(response.data);
    this.messages = response.messages.map(msg => new LoginResponseMessage(msg));
  }

  // Getter for status
  getStatus() {
    return this.status;
  }

  // Setter for status
  setStatus(status) {
    this.status = status;
  }

  // Getter for data
  getData() {
    return this.data;
  }

  // Setter for data
  setData(data) {
    this.data = new LoginResponseData(data);
  }

  // Getter for messages
  getMessages() {
    return this.messages;
  }

  // Setter for messages
  setMessages(messages) {
    this.messages = messages.map(msg => new LoginResponseMessage(msg));
  }
}

module.exports = LoginResponse;
