const Message = require("./Message");
const UccListApiResponseData = require("./UccListApiResponseData");

class UccListApiResponse {
    constructor(data) {
        this.status = data?.status || '';
        this.data = data?.data ? new UccListApiResponseData(data.data) : null;
        this.messages = new Message(data?.messages) || [];
    }
}

module.exports = UccListApiResponse;
