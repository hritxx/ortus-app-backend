class DepositoryAcctDto {
    constructor(data = {}) {
        this.euin = data?.euin || "";
        this.dp_id = data?.dp_id || "";
        this.client_id = data?.client_id || "";
      }
}

module.exports = DepositoryAcctDto ;