// const { endpoints } = require("../../constants/endpoints");
// const { errorParser } = require("../../utils/errorParser");
// const { setBearerToken } = require("../../utils/RequestFunction");
// const { api } = require("../api/Api");

// //Register XSIP
// exports.xspRegister = async (bearerToken = "", req = {}) => {
//   try {
//     let bseUrl = endpoints.sxp.sxp_register;

//     // console.log("bearerToken", bearerToken);

//     // setting bearer token in header
//     let config = setBearerToken(bearerToken);
//     // console.log("config", config);

//     //create a varaible for payload
//     let data = {
//       ...req,
//     };
//     // console.log("request create Ucc data", data);

//     const response = await api._post(bseUrl, data, config);

//     return response.data;
//   } catch (error) {
//     // console.log("errorObj in ucc", error);
//     let errorObj = errorParser(error);
//     return errorObj.data;
//   }
// };

// //Get XSP

// exports.getXsp = async ( bearerToken = "", req = {}) => {
//   try {
//     let bseUrl = endpoints.sxp.sxp_get;

//     let config = setBearerToken(bearerToken);
// \
//     //create a varaible for payload
//     let data = {
//       ...req,
//     };

//     const response = await api._post(bseUrl, data, config);

//     return response.data;
//   } catch (error) {
//     let errorObj = errorParser(error);
//     return errorObj.data;
//   }
// };

// //Pause XSP

// exports.pauseXsp = async ( bearerToken = "", req = {}) => {
//   try {
//     let bseUrl = endpoints.sxp.sxp_set_pause;

//     // setting bearer token in header
//     let config = setBearerToken(bearerToken);

//     //create a varaible for payload
//     let data = {
//       ...req,
//     };

//     const response = await api._post(bseUrl, data, config);

//     return response.data;
//   } catch (error) {
//     let errorObj = errorParser(error);
//     return errorObj.data;
//   }
// };

// //Cancel XSP

// exports.cancelXsp = async ( bearerToken = "", req = {}) => {
//   try {
//     let bseUrl = endpoints.sxp.sxp_cancel;

//     // setting bearer token in header
//     let config = setBearerToken(bearerToken);
//     // console.log("config", config);

//     //create a varaible for payload
//     let data = {
//       ...req,
//     };
//     // console.log("request create Ucc data", data);

//     const response = await api._post(bseUrl, data, config);

//     return response.data;
//   } catch (error) {
//     // console.log("errorObj in ucc", error);
//     let errorObj = errorParser(error);
//     return errorObj.data;
//   }
// };

// //Get All XSP

// exports.getAllXsp = async ( bearerToken = "", req = {}) => {
//   try {
//     let bseUrl = endpoints.sxp.sxp_list;

//     // console.log("bearerToken", bearerToken);

//     // setting bearer token in header
//     let config = setBearerToken(bearerToken);
//     // console.log("config", config);

//     //create a varaible for payload
//     let data = {
//       ...req,
//     };
//     // console.log("request create Ucc data", data);

//     const response = await api._post(bseUrl, data, config);

//     return response.data;
//   } catch (error) {
//     // console.log("errorObj in ucc", error);
//     let errorObj = errorParser(error);
//     return errorObj.data;
//   }
// };

// //Top Up XSP

// exports.topupXsp = async ( bearerToken = "", req = {}) => {
//   try {
//     let bseUrl = endpoints.sxp.sxp_topup;

//     // console.log("bearerToken", bearerToken);

//     // setting bearer token in header
//     let config = setBearerToken(bearerToken);
//     // console.log("config", config);

//     //create a varaible for payload
//     let data = {
//       ...req,
//     };

//     // console.log("request create Ucc data", data);

//     const response = await api._post(bseUrl, data, config);
//     // console.log("Top Up XSP Completed");

//     return response.data;
//   } catch (error) {
//     // console.log("errorObj in ucc", error);
//     let errorObj = errorParser(error);
//     return errorObj.data;
//   }
// };

// //Purchase New Order

// exports.purchaseNewOrder = async (

//   bearerToken = "",
//   req = {}
// ) => {
//   try {
//     let bseUrl = endpoints.order.order_new;

//     // console.log("bearerToken", bearerToken);

//     // setting bearer token in header
//     let config = setBearerToken(bearerToken);
//     // console.log("config", config);

//     //create a varaible for payload
//     let data = {
//       ...req,
//     };

//     // console.log("request create Ucc data", data);

//     const response = await api._post(bseUrl, data, config);
//     // console.log("Purchase New Order Completed");
//     return response.data;
//   } catch (error) {
//     // console.log("errorObj in ucc", error);
//     let errorObj = errorParser(error);
//     return errorObj.data;
//   }
// };

// //Update Purchase Order

// exports.updatePurchaseOrder = async (

//   bearerToken = "",
//   req = {}
// ) => {
//   try {
//     let bseUrl = endpoints.order.order_update;

//     // console.log("bearerToken", bearerToken);

//     // setting bearer token in header
//     let config = setBearerToken(bearerToken);
//     // console.log("config", config);

//     //create a varaible for payload
//     let data = {
//       ...req,
//     };

//     // console.log("request create Ucc data", data);

//     const response = await api._post(bseUrl, data, config);
//     // console.log("Update Purchase Order Completed");
//     return response.data;
//   } catch (error) {
//     // console.log("errorObj in ucc", error);
//     let errorObj = errorParser(error);
//     return errorObj.data;
//   }
// };

// //Get All Order

// exports.getAllOrders = async ( bearerToken = "", req = {}) => {
//   try {
//     let bseUrl = endpoints.order.order_list;

//     // console.log("bearerToken", bearerToken);

//     // setting bearer token in header
//     let config = setBearerToken(bearerToken);
//     // console.log("config", config);

//     //create a varaible for payload
//     let data = {
//       ...req,
//     };

//     // console.log("request create Ucc data", data);

//     const response = await api._post(bseUrl, data, config);
//     // console.log("Get All Order Completed");
//     return response.data;
//   } catch (error) {
//     // console.log("errorObj in ucc", error);
//     let errorObj = errorParser(error);
//     return errorObj.data;
//   }
// };

// //Get Order

// exports.getOrder = async ( bearerToken = "", req = {}) => {
//   try {
//     let bseUrl = endpoints.order.order_get;

//     // console.log("bearerToken", bearerToken);

//     // setting bearer token in header
//     let config = setBearerToken(bearerToken);
//     // console.log("config", config);

//     //create a varaible for payload
//     let data = {
//       ...req,
//     };

//     // console.log("request create Ucc data", data);

//     const response = await api._post(bseUrl, data, config);
//     // console.log("Get Order Completed");

//     return response.data;
//   } catch (error) {
//     // console.log("errorObj in ucc", error);
//     let errorObj = errorParser(error);
//     return errorObj.data;
//   }
// };

// //Cancel Purchase Order

// exports.cancelPurchaseOrder = async (

//   bearerToken = "",
//   req = {}
// ) => {
//   try {
//     let bseUrl = endpoints.order.order_cancel;

//     // console.log("bearerToken", bearerToken);

//     // setting bearer token in header
//     let config = setBearerToken(bearerToken);
//     // console.log("config", config);

//     //create a varaible for payload
//     let data = {
//       ...req,
//     };

//     // console.log("request create Ucc data", data);

//     const response = await api._post(bseUrl, data, config);
//     // console.log("Cancel Purchase Order Completed");

//     return response.data;
//   } catch (error) {
//     // console.log("errorObj in ucc", error);
//     let errorObj = errorParser(error);
//     return errorObj.data;
//   }
// };

const { endpoints } = require("../../constants/endpoints");
const { errorParser } = require("../../utils/errorParser");
const { setBearerToken } = require("../../utils/RequestFunction");
const Api = require("../api/Api");

class TrxnService {
  constructor(data) {
    this.api = new Api(data);
    this.endpoints = endpoints;
  }
  // Helper method to make POST requests
  async _postRequest(bearerToken, endpoint, data = {}) {
    try {
      const config = setBearerToken(bearerToken);
      const response = await this.api._post(endpoint, data, config);
      return response.data;
    } catch (error) {
      let errorObj = errorParser(error);
      return errorObj.data;
    }
  }

  // Register XSIP
  async xspRegister(bearerToken, req = {}) {
    const bseUrl = this.endpoints.sxp.sxp_register;
    return await this._postRequest(bearerToken, bseUrl, req);
  }

  // Get XSP
  async getXsp(bearerToken, req = {}) {
    const bseUrl = this.endpoints.sxp.sxp_get;
    return await this._postRequest(bearerToken, bseUrl, req);
  }

  // Pause XSP
  async pauseXsp(bearerToken, req = {}) {
    const bseUrl = this.endpoints.sxp.sxp_set_pause;
    return await this._postRequest(bearerToken, bseUrl, req);
  }

  // Cancel XSP
  async cancelXsp(bearerToken, req = {}) {
    const bseUrl = this.endpoints.sxp.sxp_cancel;
    return await this._postRequest(bearerToken, bseUrl, req);
  }

  // Get All XSP
  async getAllXsp(bearerToken, req = {}) {
    const bseUrl = this.endpoints.sxp.sxp_list;
    return await this._postRequest(bearerToken, bseUrl, req);
  }

  // Top Up XSP
  async topupXsp(bearerToken, req = {}) {
    const bseUrl = this.endpoints.sxp.sxp_topup;
    return await this._postRequest(bearerToken, bseUrl, req);
  }

  // Resume XSP
  async resumeXsp(bearerToken, req = {}) {
    const bseUrl = this.endpoints.sxp.sxp_resume;
    return await this._postRequest(bearerToken, bseUrl, req);
  }

  // Get XSP Transaction History
  async getXspTrxnHistory(bearerToken, req = {}) {
    const bseUrl = this.endpoints.sxp.sxp_get_trxn_history;
    return await this._postRequest(bearerToken, bseUrl, req);
  }

  // Purchase New Order
  async purchaseNewOrder(bearerToken, req = {}) {
    const bseUrl = this.endpoints.order.order_new;
    return await this._postRequest(bearerToken, bseUrl, req);
  }

  // Update Purchase Order
  async updatePurchaseOrder(bearerToken, req = {}) {
    const bseUrl = this.endpoints.order.order_update;
    return await this._postRequest(bearerToken, bseUrl, req);
  }

  // Get All Orders
  async getAllOrders(bearerToken, req = {}) {
    const bseUrl = this.endpoints.order.order_list;
    return await this._postRequest(bearerToken, bseUrl, req);
  }

  // Get Order
  async getOrder(bearerToken, req = {}) {
    const bseUrl = this.endpoints.order.order_get;
    return await this._postRequest(bearerToken, bseUrl, req);
  }

  // Cancel Purchase Order
  async cancelPurchaseOrder(bearerToken, req = {}) {
    const bseUrl = this.endpoints.order.order_cancel;
    return await this._postRequest(bearerToken, bseUrl, req);
  }

  //List Payment Details
  async listPaymentDetail(bearerToken, req = {}) {
    const bseUrl = this.endpoints.order.list_payment_detail;
    return await this._postRequest(bearerToken, bseUrl, req);
  }

  //Get Payment Details
  async getPaymentDetail(bearerToken, req = {}) {
    const bseUrl = this.endpoints.order.get_payment_detail;
    return await this._postRequest(bearerToken, bseUrl, req);
  }
}

module.exports = TrxnService;
