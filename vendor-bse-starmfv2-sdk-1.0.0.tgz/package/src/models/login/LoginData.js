class LoginData {
    constructor(data) {
      this.username = data.username;
      this.password = data.password;
    }
  
    // Getter for username
    getUsername() {
      return this.username;
    }
  
    // Setter for username
    setUsername(username) {
      this.username = username;
    }
  
    // Getter for password
    getPassword() {
      return this.password;
    }
  
    // Setter for password
    setPassword(password) {
      this.password = password;
    }
  }
  
  module.exports = LoginData;