const CancelOrderData = require("./CancelOrderData");

class CancelOrderRequest {
    constructor(data = {}) {
        this.data = data ? new CancelOrderData(data) : null;
    }
}

module.exports = CancelOrderRequest ;