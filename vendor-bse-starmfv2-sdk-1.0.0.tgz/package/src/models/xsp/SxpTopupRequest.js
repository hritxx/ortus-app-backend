const XspTopupData = require("./XspTopupData");

class SxpTopupRequest {
    constructor(data = {}) {
        this.data = data ? new XspTopupData(data) : "";
      }
}

module.exports = SxpTopupRequest ;