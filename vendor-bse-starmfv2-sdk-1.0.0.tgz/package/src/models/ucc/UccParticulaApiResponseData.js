const BankAccountDto = require("./BankAccountDto");
const CommAddrDto = require("./CommAddrDto");
const FatcaDto = require("./FatcaDto");
const HolderDto = require("./HolderDto");
const IdentifierDto = require("./IdentifierDto");
const InvestorDto = require("./InvestorDto");
const MemberCodeDto = require("./MemberCodeDto");

class UccParticulaApiResponseData {
  constructor(data) {
    this.member_code = data?.member_code
      ? new MemberCodeDto(data.member_code)
      : null;
    this.investor = data?.investor ? new InvestorDto(data.investor) : null;
    this.holding_nature = data?.holding_nature || "";
    this.tax_status = data?.tax_status || "";
    this.tax_code = data?.tax_code || "";
    this.rdmp_idcw_pay_mode = data?.rdmp_idcw_pay_mode || "";
    this.is_client_physical = data?.is_client_physical || false;
    this.is_client_demat = data?.is_client_demat || false;
    this.is_nomination_opted = data?.is_nomination_opted || false;
    this.nomination_auth_mode = data?.nomination_auth_mode || "";
    this.comm_mode = data?.comm_mode || "";
    this.onboarding = data?.onboarding || "";
    this.ucc_status = data?.ucc_status || "";
    this.holder = data?.holder
      ? data.holder.map((holder) => new HolderDto(holder))
      : [];
    this.comm_addr = data?.comm_addr ? new CommAddrDto(data.comm_addr) : null;
    this.foreign_addr = data?.foreign_addr
      ? new CommAddrDto(data.foreign_addr)
      : null;
    this.bank_account = data?.bank_account
      ? data.bank_account.map((account) => new BankAccountDto(account))
      : [];
    this.fatca = data?.fatca
      ? data.fatca.map((fatca) => new FatcaDto(fatca))
      : [];
    this.identifiers = data?.identifiers
      ? data.identifiers.map((identifier) => new IdentifierDto(identifier))
      : [];
  }
}

module.exports = UccParticulaApiResponseData;
