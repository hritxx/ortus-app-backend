const Address = require("./Address");
const PersonDto = require("./PersonDto");

class UboDetails {
    constructor(data) {
        this.person = data?.person ? new PersonDto(data.person) : null;
        this.beneficiary_percent = data?.beneficiary_percent || "";
        this.ubo_type_code = data?.ubo_type_code || "";
        this.address = data?.address ? new Address(data?.address) : null;
        this.pan = data?.pan || "";
        this.ubo_declaration_flag = data?.ubo_declaration_flag || "";
        this.exchange_name = data?.exchange_name || "";
        this.iB = data?.iB || "";
        this.name_of_realted_listed_company = data?.name_of_realted_listed_company || "";
        this.ubo_category = data?.ubo_category || "";
        this.politically_exposed = data?.politically_exposed || "";
        this.ubo_email_id = data?.ubo_email_id || "";
        this.smo_designation = data?.smo_designation || "";
    }
}

module.exports = UboDetails;
