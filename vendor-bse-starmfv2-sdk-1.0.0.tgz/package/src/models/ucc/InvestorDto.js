class InvestorDto {
    constructor(data) {
      this.client_code = data?.client_code; // Mapping from client_code in JSON
    }
  
    getClientCode() {
      return this.client_code;
    }
  
    setClientCode(clientCode) {
      this.client_code = clientCode;
    }
  }
  
  module.exports = InvestorDto;
  