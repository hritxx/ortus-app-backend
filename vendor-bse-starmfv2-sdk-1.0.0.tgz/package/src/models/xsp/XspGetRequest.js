const XspGetData = require("./XspGetData");

class XspGetRequest {
  constructor(data = {}) {
    this.data = data ? new XspGetData(data) : "";
  }
}

module.exports = XspGetRequest;
