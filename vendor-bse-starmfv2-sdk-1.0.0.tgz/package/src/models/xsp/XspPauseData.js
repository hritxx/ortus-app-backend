class XspPauseData {
    constructor(data = {}) {
        this.reg_no = data?.reg_no || "";
        this.ninstallments = data?.ninstallments || "";
        this.paused_from = data?.paused_from || "";
      }
}

module.exports = XspPauseData ;