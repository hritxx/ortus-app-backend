class XspMessageDto {
    constructor(data = {}) {
        this.msgid = data?.msgid || "";
        this.errcode = data?.errcode || "";
        this.field = data?.field || "";
        this.vals = data?.vals || "";
      }
}

module.exports = XspMessageDto ;