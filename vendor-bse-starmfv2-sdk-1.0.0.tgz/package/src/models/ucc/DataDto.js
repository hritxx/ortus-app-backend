// DataDto.js

const MemberCodeDto = require("./MemberCodeDto");

class DataDto {
    constructor(data) {
        this.member_code = new MemberCodeDto(data?.member_code);
        this.investor = data?.investor;
        this.holding_nature = data?.holding_nature;
        this.tax_code = data?.tax_code;
        this.rdmp_idcw_pay_mode = data?.rdmp_idcw_pay_mode;
        this.is_client_physical = data?.is_client_physical;
        this.is_client_demat = data?.is_client_demat;
        this.is_nomination_opted = data?.is_nomination_opted;
        this.nomination_auth_mode = data?.nomination_auth_mode;
        this.comm_mode = data?.comm_mode;
        this.onboarding = data?.onboarding;
        this.holder = data?.holder || [];
        this.commAddr = data?.commAddr;
        this.bankAccount = data?.bankAccount || [];
        this.fatca = data?.fatca || [];
        this.identifiers = data?.identifiers || [];
    }

    getMemberCode() {
        return this.member_code;
    }

    setMemberCode(memberCode) {
        this.member_code = new MemberCodeDto(memberCode);
    }

    getInvestor() {
        return this.investor;
    }

    setInvestor(investor) {
        this.investor = investor;
    }

    getHoldingNature() {
        return this.holding_nature;
    }

    setHoldingNature(holdingNature) {
        this.holding_nature = holdingNature;
    }

    getTaxCode() {
        return this.tax_code;
    }

    setTaxCode(taxCode) {
        this.tax_code = taxCode;
    }

    getRdmpIdcwPayMode() {
        return this.rdmp_idcw_pay_mode;
    }

    setRdmpIdcwPayMode(rdmpIdcwPayMode) {
        this.rdmp_idcw_pay_mode = rdmpIdcwPayMode;
    }

    isClientPhysical() {
        return this.is_client_physical;
    }

    setClientPhysical(isClientPhysical) {
        this.is_client_physical = isClientPhysical;
    }

    isClientDemat() {
        return this.is_client_demat;
    }

    setClientDemat(isClientDemat) {
        this.is_client_demat = isClientDemat;
    }

    isNominationOpted() {
        return this.is_nomination_opted;
    }

    setNominationOpted(isNominationOpted) {
        this.is_nomination_opted = isNominationOpted;
    }

    getNominationAuthMode() {
        return this.nomination_auth_mode;
    }

    setNominationAuthMode(nominationAuthMode) {
        this.nomination_auth_mode = nominationAuthMode;
    }

    getCommMode() {
        return this.comm_mode;
    }

    setCommMode(commMode) {
        this.comm_mode = commMode;
    }

    getOnboarding() {
        return this.onboarding;
    }

    setOnboarding(onboarding) {
        this.onboarding = onboarding;
    }

    getHolder() {
        return this.holder;
    }

    setHolder(holder) {
        this.holder = holder;
    }

    getCommAddr() {
        return this.commAddr;
    }

    setCommAddr(commAddr) {
        this.commAddr = commAddr;
    }

    getBankAccount() {
        return this.bankAccount;
    }

    setBankAccount(bankAccount) {
        this.bankAccount = bankAccount;
    }

    getFatca() {
        return this.fatca;
    }

    setFatca(fatca) {
        this.fatca = fatca;
    }

    getidentifiers() {
        return this.identifiers;
    }

    setidentifiers(identifiers) {
        this.identifiers = identifiers;
    }
}

module.exports = DataDto;
