const UccListEntry = require("./UccListEntry");

class UccListApiResponseData {
    constructor(data) {
        this.count = data?.count || 0;
        this.lists = data?.lists ? new UccListEntry(data.lists) : [];
        this.status_count_summary = data?.status_count_summary || [];
    }
}

module.exports = UccListApiResponseData;
