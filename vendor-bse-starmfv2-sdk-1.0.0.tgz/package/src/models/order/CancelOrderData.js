class CancelOrderData {
  constructor(data = {}) {
    this.id = data.id || null;
    this.remark = data.remark || "";
  }
}

module.exports = CancelOrderData;
