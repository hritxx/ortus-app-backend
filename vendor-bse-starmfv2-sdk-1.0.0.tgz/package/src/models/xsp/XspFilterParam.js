class XspFilterParam {
    constructor(data = {}) {
        this.sxp_type = data?.sxp_type || "";
        this.status = data?.status || "";
        this.freq = data?.freq || "";
      }
}

module.exports = XspFilterParam ;