class LoginResponseData {
  constructor(data) {
    this.id = data.id;
    this.name = data.name;
    // Add more fields as necessary
  }

  // Getter for id
  getId() {
    return this.id;
  }

  // Setter for id
  setId(id) {
    this.id = id;
  }

  // Getter for name
  getName() {
    return this.name;
  }

  // Setter for name
  setName(name) {
    this.name = name;
  }
}

module.exports = LoginResponseData;
