class IdentifierDto {
  constructor(data) {
    this.identifierType = data.identifier_type || "";
    this.identifierNumber = data.identifier_number || "";
    this.issueDate = data.issue_date || "";
    this.expiryDate = data.expiry_date || "";
    this.fileName = data.file_name || "";
    this.fileSize = data.file_size || 0;
    this.fileBlob = data.file_blob || "";
    this.additionalInfo = data.additional_info || "";
    this.entitySubState = data.entity_sub_state || "";
    this.isActive = data.is_active || false;
  }

  // Getter and Setter for identifierType (Java Function Name)
  getIdentifierType() {
    return this._identifierType;
  }

  setIdentifierType(value) {
    this._identifierType = value;
  }

  // Getter and Setter for identifierNumber (Java Function Name)
  getIdentifierNumber() {
    return this._identifierNumber;
  }

  setIdentifierNumber(value) {
    this._identifierNumber = value;
  }

  // Getter and Setter for issueDate (Java Function Name)
  getIssueDate() {
    return this._issueDate;
  }

  setIssueDate(value) {
    this._issueDate = value;
  }

  // Getter and Setter for expiryDate (Java Function Name)
  getExpiryDate() {
    return this._expiryDate;
  }

  setExpiryDate(value) {
    this._expiryDate = value;
  }

  // Getter and Setter for fileName (Java Function Name)
  getFileName() {
    return this._fileName;
  }

  setFileName(value) {
    this._fileName = value;
  }

  // Getter and Setter for fileSize (Java Function Name)
  getFileSize() {
    return this._fileSize;
  }

  setFileSize(value) {
    this._fileSize = value;
  }

  // Getter and Setter for fileBlob (Java Function Name)
  getFileBlob() {
    return this._fileBlob;
  }

  setFileBlob(value) {
    this._fileBlob = value;
  }

  // Getter and Setter for additionalInfo (Java Function Name)
  getAdditionalInfo() {
    return this._additionalInfo;
  }

  setAdditionalInfo(value) {
    this._additionalInfo = value;
  }

  // Getter and Setter for entitySubState (Java Function Name)
  getEntitySubState() {
    return this._entitySubState;
  }

  setEntitySubState(value) {
    this._entitySubState = value;
  }

  // Getter and Setter for isActive (Java Function Name)
  getIsActive() {
    return this._isActive;
  }

  setIsActive(value) {
    this._isActive = value;
  }
}

module.exports = IdentifierDto;
