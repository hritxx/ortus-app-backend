const InvestorDto = require("./InvestorDto");
const MemberCodeDto = require("./MemberCodeDto");
const UccListFilterParam = require("./UccListFilterParam");

class UccListRequestData {
  constructor(data) {
    this.start = data?.start || null;
    this.length = data?.length || null;
    this.fields = data?.fields || null;
    this.member_code = new MemberCodeDto(data?.member_code); // Mapping from member_code in JSON
    this.investor = new InvestorDto(data?.investor);
    this.filter_param = new UccListFilterParam(data?.filterParam); // Mapping from filter_param in JSON
    this.ucc_status = data?.ucc_status || null; // Mapping from ucc_status in JSON
  }

  getStart() {
    return this.start;
  }

  setStart(start) {
    this.start = start;
  }

  getLength() {
    return this.length;
  }

  setLength(length) {
    this.length = length;
  }

  getFields() {
    return this.fields;
  }

  setFields(fields) {
    this.fields = fields;
  }

  getMemberCode() {
    return this.member_code;
  }

  setMemberCode(memberCode) {
    this.member_code = new MemberCodeDto(memberCode);
  }

  getInvestor() {
    return this.investor;
  }

  setInvestor(investor) {
    this.investor = new InvestorDto(investor);
  }

  getFilterParam() {
    return this.filter_param;
  }

  setFilterParam(filterParam) {
    this.filter_param = new UccListFilterParam(filterParam);;
  }

  getUccStatus() {
    return this.ucc_status;
  }

  setUccStatus(uccStatus) {
    this.ucc_status = uccStatus;
  }
}

module.exports = UccListRequestData;
