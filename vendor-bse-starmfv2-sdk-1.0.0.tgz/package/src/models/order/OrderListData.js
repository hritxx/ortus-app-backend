const OrderListFilterParam = require("./OrderListFilterParam");

class OrderListData {
  constructor(data = {}) {
    this.fields = data?.fields || [];
    this.count_only = data?.count_only || false;
    this.start = data?.start || 0;
    this.length = data?.length || 0;
    this.format = data?.format || "";
    this.sort_by = data?.sort_by || "";
    this.sort_dir = data?.sort_dir || "";
    this.is_compressed = data?.is_compressed || false;
    this.search = data?.search || "";
    this.filter_param = data.filter_param
      ? new OrderListFilterParam(data.filter_param)
      : {};
  }
}

module.exports = OrderListData;
