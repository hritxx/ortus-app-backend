const TaxResidencyDto = require("./TaxResidencyDto");

class PersonDto {
    constructor(data) {
        this.first_name = data?.first_name || '';
        this.middle_name = data?.middle_name || '';
        this.last_name = data?.last_name || '';
        this.dob = data?.dob || '';
        this.gender = data?.gender || '';
        this.tax_residency = new TaxResidencyDto(data?.taxResidency) || [];
        this.place_of_birth = data?.place_of_birth || '';
        this.country_of_birth = data?.country_of_birth || '';
        this.occ_code = data?.occ_code || '';
        this.occ_type = data?.occ_type || '';
    }
}

module.exports = PersonDto;
