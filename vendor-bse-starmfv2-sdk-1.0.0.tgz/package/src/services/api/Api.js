const { default: axios } = require("axios");

class Api {
  _axios = axios.create({
    // withCredentials: true,
    baseURL: process.env.BSE_URL,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
  });

  constructor(data) {
    this._handleError = this._handleError.bind(this);
    // this._baseUrl = "https://qa.starmfv2.remiges.tech";
    console.log("API Data" , data)
    this._baseUrl = data?.baseUrl
  }

  _getFullUrl(endpoint) {
    return `${this._baseUrl}/api${endpoint}`;
  }

  _handleResponse(response) {
    return response;
  }

  async _handleError(error) {
    return Promise.reject(error);
  }

  _get(url, config = {}) {
    return this._axios
      .get(`${url}`, config)
      .then(this._handleResponse)
      .catch(this._handleError);
  }

  _post(url, data = {}, config = {}) {
    // console.log('config in api call , config' , config)
    console.log("this._getFullUrl(url)}" , this._getFullUrl(url))
    console.log("payload" , url , data)
    return this._axios
      .post(`${this._getFullUrl(url)}`, data, {...config})
      .then(this._handleResponse)
      .catch(this._handleError);
  }

  _put(url, data = {}) {
    return this._axios
      .put(`${url}`, data)
      .then(this._handleResponse)
      .catch(this._handleError);
  }
  _delete(url, payload = {}) {
    return this._axios
      .delete(`${url}`, { data: payload })
      .then(this._handleResponse)
      .catch(this._handleError);
  }
}

module.exports = Api;
