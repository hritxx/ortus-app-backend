exports.endpoints = {
  login: {
    api_login: "/login",
  },
  ucc: {
    add_ucc: "/v2/add_ucc",
    update_ucc: "/v2/update_ucc",
    list_ucc: "/v2/list_ucc",
    get_ucc: "/v2/get_ucc",
    get_ucc_status_obj: "/v2/get_ucc_status_obj",
    wh_ucc_status: "/v1/wh_ucc_status",
  },
  order: {
    order_new: "/order_new",
    order_update: "/order_update",
    order_cancel: "/order_cancel",
    order_list: "/order_list",
    order_get: "/order_get",
    wh_order_status: "/wh_order_status",
    wh_order: "/wh_order",
    list_payment_detail: "/list_payment_detail",
    get_payment_detail: "/get_payment_detail",
  },
  sxp: {
    sxp_register: "/sxp_register",
    sxp_cancel: "/sxp_cancel",
    sxp_topup: "/sxp_topup",
    sxp_set_pause: "/sxp_set_pause",
    sxp_list: "/sxp_list",
    sxp_get: "/sxp_get",
    sxp_resume: "/sxp_resume",
    sxp_get_trxn_history: "/sxp_get_history",
  },
  mandate: {
    mandate_register: "/mandate_register",
    mandate_cancel: "/mandate_cancel",
    mandate_list: "/mandate_list",
    mandate_get: "/mandate_get",
    mandate_delink: "/mandate_delink",
    link_mandate: "/link_mandate",
    mandate_update: "/mandate_update",
  },
  nomineeChange: {
    nft_nominee_change: "nft_nominee_change",
    nft_contact_change: "/v2/nft_contact_change",
    nft_bank_account_change: "/v2/nft_bank_account_change",
  },
  paymentAggregator: {
    upload_mis: "/upload_mis",
    get_mis_detail: "/get_mis_detail",
  },
  schemeList: {
    master_scheme_list: "/master_scheme_list",
  },
  nft: {
    nft_bank_account_change: "/nft_bank_account_change",
    nft_nominee_change: "/nft_nominee_change",
    nft_contact_change: "/nft_contact_change",
  },
  link2FA: {
    get_2fa_link: "/v2/get_2fa_link",
  },
  nav: {
    nav_master_list: "/nav_master_list",
  },
};
