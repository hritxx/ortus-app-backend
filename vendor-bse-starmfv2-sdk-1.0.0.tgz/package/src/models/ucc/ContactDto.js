// ContactDto.js

class ContactDto {
    constructor(contactNumber, countryCode, whoseContactNumber, emailAddress, whoseEmailAddress, contactType, isForeign) {
        this.contactNumber = data?.contact_number;
        this.countryCode = data?.country_code;
        this.whoseContactNumber = data?.whose_contact_number;
        this.emailAddress = data?.email_address;
        this.whoseEmailAddress = data?.whose_email_address;
        this.contactType = data?.contact_type;
        this.isForeign = data?.is_foreign;
    }

    getContactNumber() {
        return this.contactNumber;
    }

    setContactNumber(contactNumber) {
        this.contactNumber = contactNumber;
    }

    getCountryCode() {
        return this.countryCode;
    }

    setCountryCode(countryCode) {
        this.countryCode = countryCode;
    }

    getWhoseContactNumber() {
        return this.whoseContactNumber;
    }

    setWhoseContactNumber(whoseContactNumber) {
        this.whoseContactNumber = whoseContactNumber;
    }

    getEmailAddress() {
        return this.emailAddress;
    }

    setEmailAddress(emailAddress) {
        this.emailAddress = emailAddress;
    }

    getWhoseEmailAddress() {
        return this.whoseEmailAddress;
    }

    setWhoseEmailAddress(whoseEmailAddress) {
        this.whoseEmailAddress = whoseEmailAddress;
    }

    getContactType() {
        return this.contactType;
    }

    setContactType(contactType) {
        this.contactType = contactType;
    }

    getIsForeign() {
        return this.isForeign;
    }

    setIsForeign(isForeign) {
        this.isForeign = isForeign;
    }
}

module.exports = ContactDto;
