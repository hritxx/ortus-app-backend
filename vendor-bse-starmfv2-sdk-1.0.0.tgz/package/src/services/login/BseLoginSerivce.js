// const { endpoints } = require("../../constants/endpoints");
// const LoginRequest = require("../../models/login/LoginRequest");
// const { errorParser } = require("../../utils/errorParser");
// const { api } = require("../api/Api");

// exports.login = async (username = "", password = "") => {
//   let bseUrl = endpoints.login.api_login;

//   try {
//     let data = {
//       username: username,
//       password: password,
//     };
//     let payload = new LoginRequest(data).getData();
//     console.log("payload instace", payload)

//     // Forward request to the company API
//     const response = await api._post(bseUrl, payload, {});

//     // Send the response back to the client
//     return response.data;
//   } catch (error) {
//     let errorObj = errorParser(error);
//     return errorObj;
//   }
// };

const { endpoints } = require("../../constants/endpoints");
const LoginRequest = require("../../models/login/LoginRequest");
const { errorParser } = require("../../utils/errorParser");
const Api = require("../api/Api");
// const { api } = require("../api/Api");

class BseLoginService {
  constructor(data) {
    this.api = new Api(data);
  }

  async login(username = "", password = "") {
    let baseUrl = endpoints.login.api_login;
    try {
      let data = {
        username: username,
        password: password,
      };
      let payload = new LoginRequest(data).getData();
      // console.log("payload instance", payload);

      // Forward request to the company API
      const response = await this.api._post(baseUrl, payload, {});

      // Send the response back to the client
      return response.data;
    } catch (error) {
      let errorObj = errorParser(error);
      console.log("login Error" , errorObj?.data)
      return errorObj.data;
    }
  }
}

module.exports = BseLoginService;
