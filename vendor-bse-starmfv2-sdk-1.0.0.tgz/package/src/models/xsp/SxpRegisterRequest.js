const XspData = require("./XspData");

class SxpRegisterRequest {
  constructor(data = {}) {
    console.log("XSP Data" , data)
    this.data = data?.data ? new XspData(data?.data) : "";
  }
}

module.exports = SxpRegisterRequest;
