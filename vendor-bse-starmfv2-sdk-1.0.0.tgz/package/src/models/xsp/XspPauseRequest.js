const XspPauseData = require("./XspPauseData");

class XspPauseRequest {
  constructor(data = {}) {
    this.data = data ? new XspPauseData(data) : "";
  }
}

module.exports = XspPauseRequest;
