const DataDto = require("./DataDto");

class UccApiRequest {
    constructor(data) {
        this.data = data ? new DataDto(data) : null;
    }
}

module.exports = UccApiRequest;
