// Address.js

class Address {
    constructor(data) {
        this.address_line_1 = data?.address_line_1;
        this.address_line_2 = data?.address_line_2;
        this.address_line_3 = data?.address_line_3;
        this.postalcode = data?.postalcode;
        this.city = data?.city;
        this.state = data?.state;
        this.country = data?.country;
        this.address_type = data?.address_type;
        this.telephone = data?.telephone;
        this.mobile = data?.mobile;
    }

    getAddressLine1() {
        return this.address_line_1;
    }

    setAddressLine1(addressLine1) {
        this.address_line_1 = addressLine1;
    }

    getAddressLine2() {
        return this.address_line_2;
    }

    setAddressLine2(addressLine2) {
        this.address_line_2 = addressLine2;
    }

    getAddressLine3() {
        return this.address_line_3;
    }

    setAddressLine3(addressLine3) {
        this.address_line_3 = addressLine3;
    }

    getPostalCode() {
        return this.postalcode;
    }

    setPostalCode(postalCode) {
        this.postalcode = postalCode;
    }

    getCity() {
        return this.city;
    }

    setCity(city) {
        this.city = city;
    }

    getState() {
        return this.state;
    }

    setState(state) {
        this.state = state;
    }

    getCountry() {
        return this.country;
    }

    setCountry(country) {
        this.country = country;
    }

    getAddressType() {
        return this.address_type;
    }

    setAddressType(addressType) {
        this.address_type = addressType;
    }

    getTelephone() {
        return this.telephone;
    }

    setTelephone(telephone) {
        this.telephone = telephone;
    }

    getMobile() {
        return this.mobile;
    }

    setMobile(mobile) {
        this.mobile = mobile;
    }
}

// Export the Address class for use in other parts of the application
module.exports = Address;
