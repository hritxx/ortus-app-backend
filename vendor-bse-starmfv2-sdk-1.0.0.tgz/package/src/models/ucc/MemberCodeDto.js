class MemberCodeDto {
    constructor(data) {
        this.member_id = data?.member_id || null;
    }

    getMemberId() {
        return this.member_id;
    }

    setMemberId(member_id) {
        this.member_id = member_id;
    }
}

module.exports = MemberCodeDto ;