const Order = require("./Order");

class OrderData {
  constructor(data = {}) {
    this.orders = data.orders
      ? data.orders.map((order) => new Order(order))
      : [];
  }
}

module.exports = OrderData;
