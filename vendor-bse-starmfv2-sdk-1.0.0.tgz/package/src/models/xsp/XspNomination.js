const GuardianDto = require("../ucc/GuardianDto");
const IdentifierDto = require("../ucc/IdentifierDto");

class XspNomination {
  constructor(data = {}) {
    this.first_name = data?.first_name || "";
    this.middle_name = data?.middle_name || "";
    this.last_name = data?.last_name || "";
    this.dob = data?.dob || "";
    this.nomination_percent = data?.nomination_percent || "";
    this.nomination_relation = data?.nomination_relation || "";
    this.is_pan_exempt = data?.is_pan_exempt || false;
    this.pan_exempt_category = data?.pan_exempt_category || "";
    this.is_minor = data?.is_minor || false;
    this.identifier = data.identifier
      ? data.identifier.map((identifier) => new IdentifierDto(identifier))
      : [];
    this.guardian = data?.guardian ? new GuardianDto(data.guardian) : {};
  }
}

module.exports = XspNomination;
