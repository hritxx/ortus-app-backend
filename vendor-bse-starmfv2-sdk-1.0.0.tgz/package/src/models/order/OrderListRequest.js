const OrderListData = require("./OrderListData");

class OrderListRequest {
    constructor(data = {}) {
        this.data = data ? new OrderListData(data) : null;
      }
}

module.exports = OrderListRequest ;