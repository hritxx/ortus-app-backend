class UccListFilterParam {
    constructor(data) {
      this.tax_status = data?.tax_status || null;
      this.holding_nature = data?.holding_nature || null;
      this.is_client_physical = data?.is_client_physical || null;
      this.is_client_demat = data?.is_client_demat || null;
      this.parent_client_code = data?.parent_client_code || null;
    }
  
    getTaxStatus() {
      return this.tax_status;
    }
  
    setTaxStatus(taxStatus) {
      this.tax_status = taxStatus;
    }
  
    getHoldingNature() {
      return this.holding_nature;
    }
  
    setHoldingNature(holdingNature) {
      this.holding_nature = holdingNature;
    }
  
    getIsClientPhysical() {
      return this.is_client_physical;
    }
  
    setIsClientPhysical(isClientPhysical) {
      this.is_client_physical = isClientPhysical;
    }
  
    getIsClientDemat() {
      return this.is_client_demat;
    }
  
    setIsClientDemat(isClientDemat) {
      this.is_client_demat = isClientDemat;
    }
  
    getParentClientCode() {
      return this.parent_client_code;
    }
  
    setParentClientCode(parentClientCode) {
      this.parent_client_code = parentClientCode;
    }
  }
  
  module.exports = UccListFilterParam;
  