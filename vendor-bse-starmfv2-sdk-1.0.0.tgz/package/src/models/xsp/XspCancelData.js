class XspCancelData {
    constructor(data = {}) {
        this.reg_no = data?.reg_no || "";
        this.reason_cd = data?.reason_cd || "";
        this.reason_cd_msg = data?.reason_cd_msg || "";
      }
}

module.exports = XspCancelData ;