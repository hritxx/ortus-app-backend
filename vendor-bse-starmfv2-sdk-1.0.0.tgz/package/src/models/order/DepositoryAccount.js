class DepositoryAccount {
    constructor(data = {}) {
        this.depository = data.depository || "";
        this.dp_id = data.dp_id || "";
        this.client_id = data.client_id || "";
    }
}

module.exports = DepositoryAccount ;