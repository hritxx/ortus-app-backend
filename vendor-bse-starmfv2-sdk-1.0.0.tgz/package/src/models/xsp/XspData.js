const DepositoryAcctDto = require("./DepositoryAcctDto");
const InfoDto = require("./InfoDto");
const XspBankAccountDto = require("./XspBankAccountDto");
const XspNomination = require("./XspNomination");

class XspData {
  constructor(data = {}) {
    this.sxp_type = data?.sxp_type || "";
    this.mem_ord_ref_id = data?.mem_ord_ref_id || "";
    this.ucc = data?.ucc || "";
    this.src_scheme = data?.src_scheme || "";
    this.dest_scheme = data?.dest_scheme || "";
    this.amc_code = data?.amc_code || "";
    this.amount = data?.amount || null;
    this.cur = data?.cur || "";
    this.src_folio = data?.src_folio || "";
    this.phys_or_demat = data?.phys_or_demat || "";
    this.isunits = data?.isunits || false;
    this.dpc = data?.dpc || false;
    this.start_date = data?.start_date || "";
    this.end_date = data?.end_date || "";
    this.freq = data?.freq || "";
    this.txn_date = data?.txn_date || null;
    this.payment_ref_id = data?.payment_ref_id || "";
    this.exch_mandate_id = data?.exch_mandate_id || 0;
    this.holder = data.holder
      ? data?.holder?.map((holder) => new InfoDto(holder))
      : "";
    this.info = data.info ? new InfoDto(data.info) : "";
    this.depository_acct = data.depository_acct
      ? new DepositoryAcctDto(data.depository_acct)
      : "";
    this.bank_acct = data.bank_acct ? new XspBankAccountDto(data.bank_acct) : "";
    this.remark = data?.remark || "";
    this.email = data?.email || "";
    this.mobnum = data?.mobnum || "";
    this.first_order_today = data?.first_order_today || false;
    this.brokerage = data?.brokerage || 0;
    this.ninstallments = data?.ninstallments || 0;
    this.nomination = data.nomination ? new XspNomination(data.nomination) : "";
  }
}

module.exports = XspData;
