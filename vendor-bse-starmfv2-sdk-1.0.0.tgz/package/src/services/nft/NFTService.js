const { endpoints } = require("../../constants/endpoints");
const { errorParser } = require("../../utils/errorParser");
const { setBearerToken } = require("../../utils/RequestFunction");
const Api = require("../api/Api");

class NFTService {
  constructor(data) {
    this.api = new Api(data);
    this.endpoints = endpoints;
  }

  async nftBankAccountChange(bearerToken = "", requestDto = {}) {
    try {
      let config = setBearerToken(bearerToken);
      const response = await this.api._post(
        this.endpoints.nft.nft_bank_account_change,
        requestDto,
        config
      );
      return response.data;
    } catch (error) {
      return errorParser(error).data;
    }
  }

  async nftNomineeChange(bearerToken = "", requestDto = {}) {
    try {
      let config = setBearerToken(bearerToken);
      const response = await this.api._post(
        this.endpoints.nft.nft_nominee_change,
        requestDto,
        config
      );
      return response.data;
    } catch (error) {
      return errorParser(error).data;
    }
  }

  async nftContactChange(bearerToken = "", requestDto = {}) {
    try {
      let config = setBearerToken(bearerToken);
      const response = await this.api._post(
        this.endpoints.nft.nft_contact_change,
        requestDto,
        config
      );
      return response.data;
    } catch (error) {
      return errorParser(error).data;
    }
  }
}

module.exports = NFTService;
