const XspCancelData = require("./XspCancelData");

class XspCancelRequest {
    constructor(data = {}) {
        this.data = data ? new XspCancelData(data) : "";
      }
}

module.exports = XspCancelRequest ;