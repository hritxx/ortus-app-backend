class UccUpdateFatcaData {

}

module.exports = UccUpdateFatcaData;