class UccListStatusCountSummary {
  constructor(data = {}) {
    this.status = status;
    this.status_count = data?.status_count;
  }

  getStatus() {
    return this.status;
  }

  setStatus(status) {
    this.status = status;
  }

  getStatusCount() {
    return this.status_count;
  }

  setStatusCount(statusCount) {
    this.status_count = statusCount;
  }
}

module.exports = UccListStatusCountSummary;
