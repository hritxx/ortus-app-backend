class BseResponse {
  constructor(status, data, messages) {
    this.status = status;
    this.data = data;
    this.messages = messages;
  }

  getStatus() {
    return this.status;
  }

  setStatus(status) {
    this.status = status;
  }

  getData() {
    return this.data;
  }

  setData(data) {
    this.data = data;
  }

  getMessages() {
    return this.messages;
  }

  setMessages(messages) {
    this.messages = messages;
  }
}

module.exports = BseResponse;
