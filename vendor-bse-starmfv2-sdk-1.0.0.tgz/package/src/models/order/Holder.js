class Holder {
    constructor(data = {}) {
        this.holder_rank = data?.holder_rank || null;
        this.email = data.email || null;
        this.mobnum = data.mobnum || null;
        this.is_nomination_opted = data?.is_nomination_opted || false;
        this.nomination_auth_mode = data?.nomination_auth_mode || null;
    }
}

module.exports = Holder ;