class XspResponseData {

}

module.exports = XspResponseData ;