const MemDetailsDto = require("./MemDetailsDto");

class InfoDto {
  constructor(data = {}) {
    this.mem_details = data?.mem_details
      ? new MemDetailsDto(data.mem_details)
      : "";
  }
}

module.exports = InfoDto;
    