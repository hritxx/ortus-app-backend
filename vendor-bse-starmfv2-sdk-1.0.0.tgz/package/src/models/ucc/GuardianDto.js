const IdentifierDto = require("./IdentifierDto");

class GuardianDto {
  constructor(data) {
    this.first_name = data?.first_name;
    this.middle_name = data?.middle_name;
    this.last_name = data?.last_name;
    this.dob = data?.dob;
    this.isPanExempt = data?.is_pan_exempt;
    this.identifier = data?.identifier
      ? data.identifier.map((identifier) => new IdentifierDto(identifier))
      : [];
  }
}

module.exports = GuardianDto;
