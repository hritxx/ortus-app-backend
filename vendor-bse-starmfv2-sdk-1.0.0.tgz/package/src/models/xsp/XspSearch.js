class XspSearch {
    constructor(data = {}) {
        this.start = data?.start || "";
      }
}

module.exports = XspSearch ;