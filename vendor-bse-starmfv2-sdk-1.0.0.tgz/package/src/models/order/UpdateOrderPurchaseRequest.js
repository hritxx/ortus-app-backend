const Order = require("./Order");

class UpdateOrderPurchaseRequest {
  constructor(data = {}) {
    this.data = data ? new Order(data) : null;
  }
}

module.exports = UpdateOrderPurchaseRequest;
