class LoginResponseMessage {
    constructor(message) {
      this.code = message.code;
      this.text = message.text;
      // Add more fields as necessary
    }
  
    // Getter for code
    getCode() {
      return this.code;
    }
  
    // Setter for code
    setCode(code) {
      this.code = code;
    }
  
    // Getter for text
    getText() {
      return this.text;
    }
  
    // Setter for text
    setText(text) {
      this.text = text;
    }
  }
  
  module.exports = LoginResponseMessage;
  