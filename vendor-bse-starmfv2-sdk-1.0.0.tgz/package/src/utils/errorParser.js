 function errorParser(errorResponse) {
    let error = {};

    if (errorResponse?.response) {
        // console.log('errorResponse?.response' , errorResponse?.response?.data)
        return errorResponse?.response
    }else{
        // console.log('errorResponse' , errorResponse?.data)
        return errorResponse
    }
    return error
}

module.exports = {
    errorParser,
};