const UccListRequestData = require("./UccListRequestData");

class UccListApiRequest {
    constructor(data = null) {
      this.data = new UccListRequestData(data);
    }
  
    getData() {
      return this.data;
    }
  
    setData(data) {
      this.data = new UccListRequestData(data);
    }
  }
  
  module.exports = UccListApiRequest;
  