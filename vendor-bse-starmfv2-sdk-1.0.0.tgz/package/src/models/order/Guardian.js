const Identifier = require("./Identifier");

class Guardian {
    constructor(data = {}) {
        this.first_name = data?.first_name || null;
        this.middle_name = data?.middle_name || null;
        this.last_name = data?.last_name || null;
        this.dob = data?.dob || null;
        this.identifier = data.identifier ? data.identifier.map(item => new Identifier(item)) : null;
    }
};

module.exports = Guardian;
