class TaxResidencyDto {
    constructor(data) {
        this.country = data?.country || '';
        this.tax_id_no = data?.tax_id_no || '';
        this.tax_id_type = data?.tax_id_type || '';
    }
}

module.exports = TaxResidencyDto;
