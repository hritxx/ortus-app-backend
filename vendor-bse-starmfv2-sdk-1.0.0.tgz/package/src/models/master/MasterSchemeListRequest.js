const MasterSchemeData = require("./MasterSchemeData");

class MasterSchemeListRequest {
  constructor(data = {}) {
    this.data = data ? new MasterSchemeData(data) : null;
  }
}

module.exports = MasterSchemeListRequest;