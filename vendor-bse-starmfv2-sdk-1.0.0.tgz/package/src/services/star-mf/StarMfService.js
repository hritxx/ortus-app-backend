const BseLoginService = require("../login/BseLoginSerivce");
const UccService = require("../ucc/UccService"); // Import UCC service
const MandateService = require("../mandate/MandateService");
const TrxnOrderService = require("../trxn-order/TrxnOrderService");
const PaymentService = require("../payment/PaymentService");
const MasterDataService = require("../master-data/MasterDataService");
const ResponseHandler = require("../../utils/ResponseHandler"); // Import response handler

class StarMFService {
  constructor() {
    // BseLoginService = new BseLoginService();
    // UccService = new UccService();
  }

  // UCC Service

  //Get All UCC

  async getAllUcc(username, password, requestDto) {
    const loginResponse = await BseLoginService.login(username, password);

    if (loginResponse.status.toLowerCase() === "error") {
      console.error("getAllUcc Login API Failed");
      return loginResponse;
    }

    const uccResp = await UccService.getAllUcc(
      username,
      loginResponse.data.access_token,
      requestDto
    );

    return uccResp;
  }

  //Get Particular Ucc

  async getParticularUcc(username, password, requestDto) {
    const loginResponse = await BseLoginService.login(username, password);

    if (loginResponse.status.toLowerCase() === "error") {
      console.error("getParticularUcc Login API Failed");
      return loginResponse;
    }

    const uccResp = await UccService.getParticularUcc(
      username,
      loginResponse.data.access_token,
      requestDto
    );

    return uccResp;

    // if (uccResp.status.toLowerCase() === "error") {
    //   return uccResp
    // }
    // return ResponseHandler.sendResponse(uccResp, "UCC", 200);
  }

  //Create Individual Ucc

  async createIndividualUcc(username, password, uccApiRequest) {
    const loginResponse = await BseLoginService.login(username, password);

    if (loginResponse.status.toLowerCase() === "error") {
      console.error("createIndividualUcc Login API Failed");
      return loginResponse;
    }

    const uccResp = await UccService.createUcc(
      username,
      loginResponse.data.access_token,
      uccApiRequest
    );

    return uccResp;

    // if (uccResp.status.toLowerCase() === "error") {
    //   return uccResp
    // }

    // return ResponseHandler.sendResponse(uccResp, "UCC Created", 201);
  }

  //Update UCC Profile

  async updateUccPofile(username, password, uccApiRequest) {
    const loginResponse = await BseLoginService.login(username, password);

    if (loginResponse.status.toLowerCase() === "error") {
      console.error("updateUccPofile Login API Failed");
      return loginResponse;
    }

    const uccResp = await UccService.updateUccPofile(
      username,
      loginResponse.data.access_token,
      uccApiRequest
    );

    return uccResp;

    // if (uccResp.status.toLowerCase() === "error") {
    //   return uccResp
    // }

    // return ResponseHandler.sendResponse(uccResp, "UCC Created", 201);
  }

  //Update Communication Address Ucc

  async updateUccCommunicationAddress(
    username,
    password,
    uccUpdateCommAddressApiRequest
  ) {
    const loginResponse = await BseLoginService.login(username, password);

    if (loginResponse.status.toLowerCase() === "error") {
      console.error("updateUccAddress Login API Failed");
      return loginResponse;
    }

    const uccResp = await UccService.updateUccAddress(
      username,
      loginResponse.data.access_token,
      uccUpdateCommAddressApiRequest
    );

    return uccResp;

    // if (uccResp.status.toLowerCase() === "error") {
    //   return uccResp
    // }

    // return ResponseHandler.sendResponse(
    //   uccResp,
    //   "UCC communication address updated",
    //   200
    // );
  }

  //Update Foreign Address Ucc

  async updateUCCForeignAddress(
    username,
    password,
    uccUpdateCommAddressApiRequest
  ) {
    const loginResponse = await BseLoginService.login(username, password);

    if (loginResponse.status.toLowerCase() === "error") {
      console.error("updateUccAddress Login API Failed");
      return loginResponse;
    }

    const uccResp = await UccService.updateUccAddress(
      username,
      loginResponse.data.access_token,
      uccUpdateCommAddressApiRequest
    );

    return uccResp;

    // if (uccResp.status.toLowerCase() === "error") {
    //   return uccResp
    // }

    // return ResponseHandler.sendResponse(
    //   uccResp,
    //   "UCC communication address updated",
    //   200
    // );
  }

  //Update Ucc

  async updateUccUpdateBankData(
    memberCode,
    password,
    uccUpdateBankApiRequest
  ) {
    const loginResponse = await BseLoginService.login(memberCode, password);

    if (loginResponse.status.toLowerCase() === "error") {
      console.error("updateUccUpdateBankData Login API Failed");
      return loginResponse;
    }

    const uccResp = await UccService.updateUccUpdateBankData(
      memberCode,
      loginResponse.data.access_token,
      uccUpdateBankApiRequest
    );

    return uccResp;

    // if (uccResp.status.toLowerCase() === "error") {
    //   return uccResp
    // }

    // return ResponseHandler.sendResponse(
    //   uccResp,
    //   "UCC bank details updated",
    //   200
    // );
  }

  // Mandate Service

  //Create Mandate
  async createMandate(memberCode, password, mandateRegistrationRequest) {
    const loginResponse = await BseLoginService.login(memberCode, password);

    if (loginResponse.status.toLowerCase() === "error") {
      console.error("createMandate Login API Failed");
      return loginResponse;
    }

    const uccResp = await MandateService.createMandate(
      memberCode,
      loginResponse.data.access_token,
      mandateRegistrationRequest
    );

    return uccResp;

    // if (uccResp.status.toLowerCase() === "error") {
    //   return uccResp
    // }

    // return ResponseHandler.sendResponse(
    //   uccResp,
    //   "UCC bank details updated",
    //   200
    // );
  }

  //Get Mandate

  async getMandate(memberCode, password, req) {
    const loginResponse = await BseLoginService.login(memberCode, password);

    if (loginResponse.status.toLowerCase() === "error") {
      console.error("getMandate Login API Failed");
      return loginResponse;
    }

    const uccResp = await MandateService.getMandate(
      memberCode,
      loginResponse.data.access_token,
      req
    );

    return uccResp;

    // if (uccResp.status.toLowerCase() === "error") {
    //   return uccResp
    // }

    // return ResponseHandler.sendResponse(
    //   uccResp,
    //   "UCC bank details updated",
    //   200
    // );
  }

  //Get All Mandate
  async getAllMandate(memberCode, password, req) {
    const loginResponse = await BseLoginService.login(memberCode, password);

    if (loginResponse.status.toLowerCase() === "error") {
      console.error("getAllMandate Login API Failed");
      return loginResponse;
    }

    const uccResp = await MandateService.getAllMandate(
      memberCode,
      loginResponse.data.access_token,
      req
    );

    return uccResp;
  }

  // Cancel Mandate

  async cancelMandate(memberCode, password, req) {
    const loginResponse = await BseLoginService.login(memberCode, password);

    if (loginResponse.status.toLowerCase() === "error") {
      console.error("cancelMandate Login API Failed");
      return loginResponse;
    }

    const uccResp = await MandateService.cancelMandate(
      memberCode,
      loginResponse.data.access_token,
      req
    );

    return uccResp;
  }

  //XSP Services

  //Register XSP

  async xspRegister(memberCode, password, req) {
    const loginResponse = await BseLoginService.login(memberCode, password);

    if (loginResponse.status.toLowerCase() === "error") {
      console.error("xspRegister Login API Failed");
      return loginResponse;
    }

    const uccResp = await TrxnOrderService.xspRegister(
      memberCode,
      loginResponse.data.access_token,
      req
    );

    return uccResp;
  }

  //Get XSP

  async getXsp(memberCode, password, req) {
    const loginResponse = await BseLoginService.login(memberCode, password);

    if (loginResponse.status.toLowerCase() === "error") {
      console.error("getXsp Login API Failed");
      return loginResponse;
    }

    const uccResp = await TrxnOrderService.getXsp(
      memberCode,
      loginResponse.data.access_token,
      req
    );

    return uccResp;
  }

  //Pause XSP

  async pauseXsp(memberCode, password, req) {
    const loginResponse = await BseLoginService.login(memberCode, password);

    if (loginResponse.status.toLowerCase() === "error") {
      console.error("pauseXsp Login API Failed");
      return loginResponse;
    }

    const uccResp = await TrxnOrderService.pauseXsp(
      memberCode,
      loginResponse.data.access_token,
      req
    );

    return uccResp;
  }

  //Cancel XSP

  async cancelXsp(memberCode, password, req) {
    const loginResponse = await BseLoginService.login(memberCode, password);

    if (loginResponse.status.toLowerCase() === "error") {
      console.error("cancelXsp Login API Failed");
      return loginResponse;
    }

    const uccResp = await TrxnOrderService.cancelXsp(
      memberCode,
      loginResponse.data.access_token,
      req
    );

    return uccResp;
  }

  //Get All XSP

  async getAllXsp(memberCode, password, req) {
    const loginResponse = await BseLoginService.login(memberCode, password);

    if (loginResponse.status.toLowerCase() === "error") {
      console.error("getAllXsp Login API Failed");
      return loginResponse;
    }

    const uccResp = await TrxnOrderService.getAllXsp(
      memberCode,
      loginResponse.data.access_token,
      req
    );

    return uccResp;
  }

  // Top-up XSP

  async topupXsp(memberCode, password, req) {
    const loginResponse = await BseLoginService.login(memberCode, password);

    if (loginResponse.status.toLowerCase() === "error") {
      console.error("topupXsp Login API Failed");
      return loginResponse;
    }

    const uccResp = await TrxnOrderService.topupXsp(
      memberCode,
      loginResponse.data.access_token,
      req
    );

    return uccResp;
  }

  // Purchase New Order

  async purchaseNewOrder(memberCode, password, req) {
    const loginResponse = await BseLoginService.login(memberCode, password);

    if (loginResponse.status.toLowerCase() === "error") {
      console.error("purchaseNewOrder Login API Failed");
      return loginResponse;
    }

    const uccResp = await TrxnOrderService.purchaseNewOrder(
      memberCode,
      loginResponse.data.access_token,
      req
    );

    return uccResp;
  }

  // Update Purchase Order

  async updatePurchaseOrder(memberCode, password, req) {
    const loginResponse = await BseLoginService.login(memberCode, password);

    if (loginResponse.status.toLowerCase() === "error") {
      console.error("updatePurchaseOrder Login API Failed");
      return loginResponse;
    }

    const uccResp = await TrxnOrderService.updatePurchaseOrder(
      memberCode,
      loginResponse.data.access_token,
      req
    );

    return uccResp;
  }

  // Get All Order

  async getAllOrders(memberCode, password, req) {
    const loginResponse = await BseLoginService.login(memberCode, password);

    if (loginResponse.status.toLowerCase() === "error") {
      console.error("getAllOrders Login API Failed");
      return loginResponse;
    }

    const uccResp = await TrxnOrderService.getAllOrders(
      memberCode,
      loginResponse.data.access_token,
      req
    );

    return uccResp;
  }

  // Get Order

  async getOrder(memberCode, password, req) {
    const loginResponse = await BseLoginService.login(memberCode, password);

    if (loginResponse.status.toLowerCase() === "error") {
      console.error("getOrder Login API Failed");
      return loginResponse;
    }

    const uccResp = await TrxnOrderService.getOrder(
      memberCode,
      loginResponse.data.access_token,
      req
    );

    return uccResp;
  }

  // Cancel Purchase Order

  async cancelPurchaseOrder(memberCode, password, req) {
    const loginResponse = await BseLoginService.login(memberCode, password);

    if (loginResponse.status.toLowerCase() === "error") {
      console.error("cancelPurchaseOrder Login API Failed");
      return loginResponse;
    }

    const uccResp = await TrxnOrderService.cancelPurchaseOrder(
      memberCode,
      loginResponse.data.access_token,
      req
    );

    return uccResp;
  }

  // Payment Report

  async paymentReport(memberCode, password, req) {
    const loginResponse = await BseLoginService.login(memberCode, password);

    if (loginResponse.status.toLowerCase() === "error") {
      console.error("cancelPurchaseOrder Login API Failed");
      return loginResponse;
    }

    const uccResp = await PaymentService.paymentReport(
      memberCode,
      loginResponse.data.access_token,
      req
    );

    return uccResp;
  }

  //Get Payment Details

  async getPaymentMisDetails(memberCode, password, req) {
    const loginResponse = await BseLoginService.login(memberCode, password);

    if (loginResponse.status.toLowerCase() === "error") {
      console.error("cancelPurchaseOrder Login API Failed");
      return loginResponse;
    }

    const uccResp = await PaymentService.getPaymentMisDetails(
      memberCode,
      loginResponse.data.access_token,
      req
    );

    return uccResp;
  }

  //Get Scheme Master List

  async getSchemeMasterList(memberCode, password, req) {
    const loginResponse = await BseLoginService.login(memberCode, password);

    if (loginResponse.status.toLowerCase() === "error") {
      console.error("cancelPurchaseOrder Login API Failed");
      return loginResponse;
    }

    const uccResp = await MasterDataService.getSchemeMasterList(
      loginResponse.data.access_token,
      req
    );

    return uccResp;
  }
}

module.exports = new StarMFService();
