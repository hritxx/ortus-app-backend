class XspTopupData {
    constructor(data = {}) {
        this.reg_no = data?.reg_no || "";
        this.amount = data?.amount || "";
        this.cur = data?.cur || "";
      }
}

module.exports = XspTopupData ;