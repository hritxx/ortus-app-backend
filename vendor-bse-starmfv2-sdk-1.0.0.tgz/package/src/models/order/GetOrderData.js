const OrderListFilterParam = require("./OrderListFilterParam");

class GetOrderData {
  constructor(data = {}) {
    this.id = data.id || null;
    this.filter_param = data.filter_param
      ? new OrderListFilterParam(data.filter_param)
      : null;
  }
}

module.exports = GetOrderData;
