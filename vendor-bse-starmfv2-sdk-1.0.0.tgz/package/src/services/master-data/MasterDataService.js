// const { endpoints } = require("../../constants/endpoints");
// const { errorParser } = require("../../utils/errorParser");
// const { setBearerToken } = require("../../utils/RequestFunction");
// const { api } = require("../api/Api");

// //Get Scheme Master List

// exports.getSchemeMasterList = async (
//   bearerToken = "",
//   req = {}
// ) => {
//   try {
//     let bseUrl = endpoints.schemeList.master_scheme_list;

//     // console.log("bearerToken", bearerToken);

//     // setting bearer token in header
//     let config = setBearerToken(bearerToken);
//     // console.log("config", config);

//     //create a varaible for payload
//     let data = {
//       ...req,
//     };

//     // console.log("request create Ucc data", data);

//     const response = await api._post(bseUrl, data, config);
//     // console.log("Cancel Purchase Order Completed");

//     return response.data;
//   } catch (error) {
//     // console.log("errorObj in ucc", error);
//     let errorObj = errorParser(error);
//     return errorObj.data;
//   }
// };

const { endpoints } = require("../../constants/endpoints");
const { errorParser } = require("../../utils/errorParser");
const { setBearerToken } = require("../../utils/RequestFunction");
const Api = require("../api/Api");

class MasterDataService {
  constructor(data) {
    this.api = new Api(data);
    this.endpoints = endpoints;
  }

  async getSchemeMasterList(bearerToken = "", req = {}) {
    try {
      const bseUrl = this.endpoints.schemeList.master_scheme_list;
      const config = setBearerToken(bearerToken);
      const data = { ...req };
      const response = await this.api._post(bseUrl, data, config);
      return response.data;
    } catch (error) {
      const errorObj = errorParser(error);
      return errorObj.data;
    }
  }
}

module.exports = MasterDataService;
