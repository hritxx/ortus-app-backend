const IdentifierDto = require("./IdentifierDto");

class Depository {
  constructor(data) {
    this.depository_code = data?.depository_code;
    this.dp_id = data?.dp_id;
    this.client_id = data?.client_id;
    this.cmbp_id = data?.cmbp_id;
    this.bank_account = data?.bank_account;
    this.account_owner = data?.account_owner;
    this.identifiers = data?.identifiers
      ? data.identifiers.map((identifier) => new IdentifierDto(identifier))
      : [];
  }

  getDepositoryCode() {
    return this.depository_code;
  }

  setDepositoryCode(depositoryCode) {
    this.depository_code = depositoryCode;
  }

  getDpId() {
    return this.dp_id;
  }

  setDpId(dpId) {
    this.dp_id = dpId;
  }

  getClientId() {
    return this.client_id;
  }

  setClientId(clientId) {
    this.client_id = clientId;
  }

  getCmbpId() {
    return this.cmbp_id;
  }

  setCmbpId(cmbpId) {
    this.cmbp_id = cmbpId;
  }

  getBankAccount() {
    return this.bank_account;
  }

  setBankAccount(bankAccount) {
    this.bank_account = bankAccount;
  }

  getAccountOwner() {
    return this.account_owner;
  }

  setAccountOwner(accountOwner) {
    this.account_owner = accountOwner;
  }

  getIdentifier() {
    return this.identifier;
  }

  setIdentifier(identifier) {
    this.identifier = new IdentifierDto(identifier);
  }
}

module.exports = Depository;
