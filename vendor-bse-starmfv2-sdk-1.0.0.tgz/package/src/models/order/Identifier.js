class Identifier {
    constructor(data = {}) {
        this.identifier_type = data?.identifier_type || null;
        this.identifier_number = data.identifier_number || null;
    }
}

module.exports = Identifier ;