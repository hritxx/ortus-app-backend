const UboDetails = require("./UboDetails");

class Ubo {
    constructor(data) {
        this.is_ubo_applicable = data?.is_ubo_applicable || false;
        this.ubo_count = data?.ubo_count || 0;
        this.ubo_detail = new UboDetails(data?.ubo_detail) || [];
    }
}

module.exports = Ubo;
