const IdentifierDto = require("./IdentifierDto");
const TaxResidencyDto = require("./TaxResidencyDto");

class FatcaDto {
    constructor(data) {
        this.holderRank = data?.HolderRank;
        this.place_of_birth = data?.place_of_birth;
        this.country_of_birth = data?.country_of_birth;
        this.client_name = data?.client_name;
        this.investor_type = data?.investor_type;
        this.dob = data?.dob;
        this.father_name = data?.father_name;
        this.spouse_name = data?.spouse_name;
        this.address_type = data?.address_type;
        this.occ_code = data?.occ_code;
        this.occ_type = data?.occ_type;
        this.occ_type = data?.occ_type;
        this.exemption_code = data?.exemption_code;
        this.identifiers = data?.identifiers
        ? data.identifiers.map((identifier) => new IdentifierDto(identifier))
        : [];
        this.corporate_service_sector = data?.corporate_service_sector;
        this.wealth_source = data?.wealth_source;
        this.income_slab = data?.income_slab;
        this.net_worth = data?.net_worth;
        this.date_of_net_worth = data?.date_of_net_worth;
        this.politically_exposed = data?.politically_exposed;
        this.is_self_declared = data?.is_self_declared;
        this.data_source = data?.data_source;
        this.taxResidency = new TaxResidencyDto(data?.tax_residency);
        this.uccId = data?.ucc_id;
        this.fatcaId = data?.fatca_id;
        this.logName = data?.log_name;
    }
}

module.exports = FatcaDto