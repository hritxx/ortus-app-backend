const BseLoginService = require("./services/login/BseLoginSerivce");
const UccService = require("./services/ucc/UccService");
const TrxnService = require("./services/trxn-order/TrxnOrderService");
const MasterDataService = require("./services/master-data/MasterDataService");
const PaymentService = require("./services/payment/PaymentService");
const MandateService = require("./services/mandate/MandateService");
const NFTService = require("./services/nft/NFTService");
const Fetch2FALinkService = require("./services/link-2FA/Fetch2FALinkService");
const NavService = require("./services/nav/NavService");

module.exports = {
  BseLoginService,
  UccService,
  TrxnService,
  MandateService,
  MasterDataService,
  PaymentService,
  NFTService,
  Fetch2FALinkService,
  NavService
};
