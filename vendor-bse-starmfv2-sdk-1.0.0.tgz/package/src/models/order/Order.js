const BankAccount = require("./BankAccount");
const DepositoryAccount = require("./DepositoryAccount");
const Holder = require("./Holder");
const Investor = require("./Investor");
const Nomination = require("./Nomination");

class Order {
  constructor(data = {}) {
    this.id = data?.id || 0;
    this.src = data?.src || "";
    this.type = data?.type || "";
    this.mem_ord_ref_id = data?.mem_ord_ref_id || "";
    this.investor = data?.investor ? new Investor(data?.investor) : {};
    this.member = data?.member || "";
    this.scheme = data?.scheme || "";
    this.amount = data?.amount || 0;
    this.cur = data?.cur || "";
    this.is_units = data?.is_units || false;
    this.all_units = data?.all_units || false;
    this.folio = data?.folio || "";
    this.is_fresh = data?.is_fresh || false;
    this.phys_or_demat = data?.phys_or_demat || "";
    this.info = data?.info || {};
    this.holder = data.holder
      ? data.holder.map((holder) => new Holder(holder))
      : [];
    this.email = data?.email || "";
    this.mobnum = data?.mobnum || "";
    this.exch_mandate_id = data?.exch_mandate_id || 0;
    this.kyc_passed = data?.kyc_passed || false;
    this.depository_acct = data.depository_acct
      ? new DepositoryAccount(data.depository_acct)
      : {};
    this.bank_acct = data.bank_acct ? new BankAccount(data.bank_acct) : {};
    this.dpc = data?.dpc || false;
    this.nomination = data.nomination
      ? data.nomination.map((nomination) => new Nomination(nomination))
      : [];
    this.remark = data?.remark || "";
  }
}

module.exports = Order;
