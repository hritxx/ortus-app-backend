const LoginData = require("./LoginData");

class LoginRequest {
  constructor(data) {
    this.data = new LoginData(data);
  }

  // Getter for data
  getData() {
    return {data :this.data};
  }

  // Setter for data
  setData(data) {
    this.data = new LoginData(data);
  }
}

module.exports = LoginRequest ;