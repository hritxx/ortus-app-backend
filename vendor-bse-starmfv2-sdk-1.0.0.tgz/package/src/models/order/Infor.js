const MemberDetails = require("./MemberDetails");

class info {
    constructor(data = {}) {
        this.min_redeem_flag = data?.min_redeem_flag || "";
        this.src = data?.src || "";
        this.reg_no = data?.reg_no || "";
        this.mem_details = data.mem_details ? new MemberDetails(data.mem_details) : "";
      }
}

module.exports = info ;