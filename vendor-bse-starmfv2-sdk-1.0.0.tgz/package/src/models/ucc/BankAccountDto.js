// BankAccountDto.js

const IdentifierDto = require("./IdentifierDto");

class BankAccountDto {
  constructor(data) {
    this.ifsc_code = data?.ifsc_code;
    this.bank_acc_num = data?.bank_acc_num;
    this.no = data?.no;
    this.bank_acc_type = data?.bank_acc_type;
    this.type = data?.type;
    this.name = data?.name;
    this.account_owner = data?.account_owner;
    this.identifiers = data?.identifiers
      ? data.identifiers.map((identifier) => new IdentifierDto(identifier))
      : [];
  }

  getIfscCode() {
    return this.ifsc_code;
  }

  setIfscCode(ifscCode) {
    this.ifsc_code = ifscCode;
  }

  getBankAccNum() {
    return this.bank_acc_num;
  }

  setBankAccNum(bankAccNum) {
    this.bank_acc_num = bankAccNum;
  }

  getNo() {
    return this.no;
  }

  setNo(no) {
    this.no = no;
  }

  getBankAccType() {
    return this.bank_acc_type;
  }

  setBankAccType(bankAccType) {
    this.bank_acc_type = bankAccType;
  }

  getType() {
    return this.type;
  }

  setType(type) {
    this.type = type;
  }

  getName() {
    return this.name;
  }

  setName(name) {
    this.name = name;
  }

  getAccountOwner() {
    return this.account_owner;
  }

  setAccountOwner(accountOwner) {
    this.account_owner = accountOwner;
  }

  getIdentifier() {
    return this.identifier;
  }

  setIdentifier(identifier) {
    this.identifier = identifier?.map((item) => new IdentifierDto(item));
  }
}

module.exports = BankAccountDto;
