exports.setBearerToken = (token) => {
  return {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  };
};
