class OrderListFilterParam {
    constructor(data = {}) {
        this.open_close = data?.open_close || "";
      }
}

module.exports = OrderListFilterParam;