const MasterFilterParam = require("./MasterFilterParam");
const MasterSearch = require("./MasterSearch");

class MasterSchemeData {
    constructor(data = {}) {
        this.start = data?.start || 0;
        this.length = data?.length || 0;
        this.fields = data?.fields || [];
        this.count_only = data?.count_only || false;
        this.filter_param = data?.filter_param ? new MasterFilterParam(data?.filter_param) : null;
        this.search = data.search ? new MasterSearch(data.search) : null;
    }
}

module.exports = MasterSchemeData;
