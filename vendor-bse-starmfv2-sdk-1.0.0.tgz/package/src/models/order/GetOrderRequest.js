const GetOrderData = require("./GetOrderData");

this.GetOrderRequest = class {
    constructor(data = {}) {
        this.data = data ? new GetOrderData(data) : null;
    }
};

module.exports = GetOrderRequest;