class HolderDto {
  constructor({
    holderRank,
    occCode,
    authMode,
    isPanExempt,
    panExemptCategory,
    identifier = [],
    kycType,
    ckycNumber,
    person,
    contact = [],
    nomination = [],
    panVerified,
    email,
    mobnum,
    isNominationOpted,
    nominationAuthMode,
  }) {
    this.holderRank = holderRank;
    this.occCode = occCode;
    this.authMode = authMode;
    this.isPanExempt = isPanExempt;
    this.panExemptCategory = panExemptCategory;
    this.identifier = data?.identifier
      ? data.identifier.map((identifier) => new IdentifierDto(identifier))
      : [];
    this.kycType = kycType;
    this.ckycNumber = ckycNumber;
    this.person = person ? new PersonDto(person.name, person.dob) : null;
    this.contact = contact.map((cont) => new ContactDto(cont.type, cont.value));
    this.nomination = nomination.map(
      (nom) => new NominationDto(nom.nomineeName, nom.nomineeRelation)
    );
    this.panVerified = panVerified;
    this.email = email;
    this.mobnum = mobnum;
    this.isNominationOpted = isNominationOpted;
    this.nominationAuthMode = nominationAuthMode;
  }
}

module.exports = HolderDto;
