const XspGetListData = require("./XspGetListData");

class XspGetListRequest {
  constructor(data = {}) {
    this.data = data ? new XspGetListData(data) : "";
  }
}

module.exports = XspGetListRequest;
