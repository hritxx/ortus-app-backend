const Guardian = require("./Guardian");
const Identifier = require("./Identifier");

class Nomination {
  constructor(data = {}) {
    this.first_name = data?.first_name || "";
    this.middle_name = data?.middle_name || "";
    this.last_name = data?.last_name || "";
    this.dob = data?.dob || "";
    this.nomination_percent = data?.nomination_percent || 0;
    this.nomination_relation = data?.nomination_relation || "";
    this.is_pan_exempt = data?.is_pan_exempt || false;
    this.pan_exempt_category = data?.pan_exempt_category || "";
    this.is_minor = data?.is_minor || false;
    this.identifier = data.identifier
      ? data.identifier.map((identifier) => new Identifier(identifier))
      : [];
    this.guardian = data.guardian ? new Guardian(data.guardian) : {};
  }
}

module.exports = Nomination;
