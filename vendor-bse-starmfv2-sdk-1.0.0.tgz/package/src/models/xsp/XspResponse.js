const XspMessageDto = require("./XspMessageDto");
const XspResponseData = require("./XspResponseData");

class XspResponse {
    constructor(data = {}) {
        this.status = data?.status || "";
        this.amount = data.data  ? new XspResponseData(data.data) :  "";
        this.messages = data?.messages?.map((message => new XspMessageDto(message));
      }
}

module.exports = XspResponse ;