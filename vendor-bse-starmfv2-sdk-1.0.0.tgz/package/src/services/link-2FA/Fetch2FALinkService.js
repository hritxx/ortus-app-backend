const { endpoints } = require("../../constants/endpoints");
const { errorParser } = require("../../utils/errorParser");
const { setBearerToken } = require("../../utils/RequestFunction");
const Api = require("../api/Api");

class Fetch2FALinkService {
  constructor(data) {
    this.api = new Api(data);
    this.endpoints = endpoints;
  }

  async get2FALink(bearerToken = "", get2FARequestDto = {}) {
    try {
      let config = setBearerToken(bearerToken);
      let data = { ...get2FARequestDto };
      const response = await this.api._post(
        this.endpoints.link2FA.get_2fa_link,
        data,
        config
      );
      return response.data;
    } catch (error) {
      console.log("Create UCC Error", errorParser(error).data);
      return errorParser(error).data;
    }
  }

  async get2FAUccNom(bearerToken = "", get2FARequestDto = {}) {
    return this.get2FALink(bearerToken, get2FARequestDto);
  }

  async get2FAUccElog(bearerToken = "", get2FARequestDto = {}) {
    return this.get2FALink(bearerToken, get2FARequestDto);
  }

  async get2FAVerifyMandateCancel(bearerToken = "", get2FARequestDto = {}) {
    return this.get2FALink(bearerToken, get2FARequestDto);
  }

  async get2FAVerifySxpReg(bearerToken = "", get2FARequestDto = {}) {
    return this.get2FALink(bearerToken, get2FARequestDto);
  }

  async get2FAVerifyOrderCancel(bearerToken = "", get2FARequestDto = {}) {
    return this.get2FALink(bearerToken, get2FARequestDto);
  }
}

module.exports = Fetch2FALinkService;